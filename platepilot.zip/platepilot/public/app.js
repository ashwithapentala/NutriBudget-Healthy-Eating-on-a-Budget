'use strict';

/* PlatePilot front end. Plain ES6, no build step. */

const SLOT_LABEL = { breakfast: 'Breakfast', lunch: 'Lunch', snack: 'Snack', dinner: 'Dinner' };
const SLOT_ORDER = ['breakfast', 'lunch', 'snack', 'dinner'];
const MACRO_COLORS = { protein: '#bf4a14', carbs: '#e0922f', fat: '#2f6b45' };

const state = {
  meta: null,
  profile: null,      // the profile the server actually used
  days: [],           // fully described days from the server
  day: 0,
  seen: {},           // dishes already swapped away from, per "day:slot"
  seed: 1,
  groceryDirty: true,
  charts: [],
  messBudget: 40,
  tab: 'plan',
};

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

// Tiny element builder. Everything goes through textContent, so user-submitted
// recipe text can never inject markup.
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === false || v == null) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) {
    if (kid == null || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

const rupee = (n) => `₹${Math.round(n)}`;
const rupee1 = (n) => `₹${Number.isInteger(n) ? n : n.toFixed(1)}`;
function fmtQty(q, unit) {
  if (unit === 'pc') return `${q} ${q === 1 ? 'pc' : 'pcs'}`;
  if (q >= 1000) return `${Number((q / 1000).toFixed(2))} ${unit === 'ml' ? 'L' : 'kg'}`;
  return `${q} ${unit}`;
}
const dietLabel = { vegan: 'Vegan', veg: 'Veg', nonveg: 'Non-veg' };

async function api(path, body) {
  const opts = body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined;
  const res = await fetch(`/api${path}`, opts);
  let data = {};
  try { data = await res.json(); } catch { /* empty body */ }
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}

let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3200);
}

// ------------------------------------------------------------ storage

const store = {
  get(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode, quota */ }
  },
};

function clientId() {
  let id = store.get('platepilot.client', null);
  if (!id) {
    id = Math.random().toString(36).slice(2, 12);
    store.set('platepilot.client', id);
  }
  return id;
}

function persistPlan() {
  store.set('platepilot.last', { profile: state.profile, days: state.days, seed: state.seed });
}

// ------------------------------------------------------------- profile

function readProfile() {
  const kcal = $('#kcal').value.trim();
  return {
    budget: Number($('#budget').value),
    diet: $('input[name=diet]:checked').value,
    goal: $('input[name=goal]:checked').value,
    weightKg: Number($('#weight').value),
    kcalOverride: kcal === '' ? undefined : Number(kcal),
    priceMult: Number($('#priceMult').value) / 100,
    pantry: $$('#pantryBox input:checked').map((i) => i.value),
    days: Number($('input[name=days]:checked').value),
    seed: state.seed,
  };
}

function writeProfile(p) {
  if (!p) return;
  $('#budget').value = p.budget;
  $('#budgetRange').value = Math.min(300, Math.max(60, p.budget));
  const pick = (name, v) => { const r = $(`input[name=${name}][value="${v}"]`); if (r) r.checked = true; };
  pick('diet', p.diet); pick('goal', p.goal); pick('days', p.days);
  $('#weight').value = p.weightKg;
  $('#kcal').value = p.kcalOverride || '';
  $('#priceMult').value = Math.round((p.priceMult || 1) * 100);
  $('#priceOut').textContent = `${$('#priceMult').value}%`;
  const have = new Set(p.pantry || []);
  $$('#pantryBox input').forEach((i) => { i.checked = have.has(i.value); });
  updatePantryCount();
}

function updatePantryCount() {
  const n = $$('#pantryBox input:checked').length;
  $('#pantryCount').textContent = n ? `(${n} selected)` : '';
}

function buildPantry() {
  const box = $('#pantryBox');
  const skip = new Set(['spice', 'tea']);
  for (const ing of state.meta.ingredients) {
    if (skip.has(ing.id)) continue;
    box.append(h('label', { class: 'chip' },
      h('input', { type: 'checkbox', value: ing.id, onchange: updatePantryCount }),
      h('span', null, ing.name)));
  }
}

// ---------------------------------------------------------- generation

async function generate({ keepSeed = false } = {}) {
  const btn = $('#generateBtn');
  const err = $('#formError');
  err.hidden = true;
  if (!keepSeed) state.seed = Math.floor(Math.random() * 1e6) + 1;
  btn.disabled = true;
  btn.textContent = 'Planning your meals…';
  try {
    const res = await api('/plan', { profile: readProfile() });
    state.profile = res.profile;
    state.days = res.days;
    state.day = 0;
    state.seen = {};
    state.groceryDirty = true;
    store.set('platepilot.form', res.profile);
    persistPlan();
    setTab('plan');
    renderPlan();
    if (window.matchMedia('(max-width: 960px)').matches) $('#tab-plan').scrollIntoView({ behavior: 'smooth' });
  } catch (e) {
    err.textContent = e.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Generate budget diet plan';
  }
}

async function swap(slot, button) {
  const key = `${state.day}:${slot}`;
  const seen = (state.seen[key] ||= []);
  const current = state.days[state.day];
  seen.push(current.slots[slot].id);
  button.disabled = true;
  try {
    const res = await api('/swap', { profile: state.profile, day: current.pick, slot, exclude: seen });
    state.days[state.day] = res.day;
    state.groceryDirty = true;
    persistPlan();
    renderPlan(slot);
    toast(`Swapped ${res.replaced} for ${res.day.slots[slot].name}`);
  } catch (e) {
    state.seen[key] = []; // we've run out of options, so start the cycle again
    button.disabled = false;
    toast(e.message);
  }
}

// -------------------------------------------------------------- plan UI

function destroyCharts() {
  state.charts.forEach((c) => c.destroy());
  state.charts = [];
}

function renderPlan(flashSlot) {
  const body = $('#planBody');
  destroyCharts();
  body.replaceChildren();
  if (!state.days.length) {
    $('#planEmpty').hidden = false;
    body.hidden = true;
    return;
  }
  $('#planEmpty').hidden = true;
  body.hidden = false;
  const day = state.days[state.day];
  const pending = [];

  body.append(toolbar());
  if (state.days.length > 1) body.append(dayTabs());
  body.append(summaryCard(day));
  day.warnings.forEach((w) => body.append(h('div', { class: 'banner', role: 'note' }, w)));
  body.append(mealGrid(day, flashSlot));
  body.append(chartsCard(day, pending));

  // Charts need their canvases in the page before they can draw.
  requestAnimationFrame(() => pending.forEach((fn) => fn()));
}

function toolbar() {
  const saved = store.get('platepilot.saved', []);
  const select = h('select', {
    'aria-label': 'Load a saved plan',
    onchange: (e) => {
      const plan = saved[Number(e.target.value)];
      if (!plan) return;
      state.profile = plan.profile; state.days = plan.days; state.day = 0; state.seen = {};
      state.groceryDirty = true;
      writeProfile(plan.profile);
      persistPlan();
      renderPlan();
      toast('Loaded saved plan');
    },
  }, h('option', { value: '' }, saved.length ? 'Load saved plan…' : 'No saved plans yet'),
    saved.map((p, i) => h('option', { value: i }, p.name)));
  select.disabled = !saved.length;

  return h('div', { class: 'toolbar' },
    h('div', { class: 'group' },
      h('button', { class: 'btn small', type: 'button', onclick: () => generate() }, '↻ New plan'),
      h('button', { class: 'btn small', type: 'button', onclick: savePlan }, 'Save plan'),
      select),
    h('div', { class: 'group' },
      h('button', { class: 'btn small', type: 'button', onclick: printSheet }, 'Print 7-day cheat sheet')));
}

function dayTabs() {
  return h('div', { class: 'daytabs', role: 'tablist', 'aria-label': 'Days' },
    state.days.map((d, i) => h('button', {
      class: `daytab${i === state.day ? ' is-active' : ''}`, type: 'button', role: 'tab',
      'aria-selected': i === state.day ? 'true' : 'false',
      onclick: () => { state.day = i; renderPlan(); },
    }, `Day ${i + 1} · ${rupee(d.totals.cost)}`)));
}

function summaryCard(day) {
  const t = day.totals, g = day.targets;
  const pct = Math.min(100, (t.cost / day.budget) * 100);
  const proteinOk = t.protein >= g.protein * 0.9;
  const stat = (label, value, target, unit, ok) => h('div', { class: `stat ${ok ? 'ok' : ''}` },
    h('b', null, `${value}${unit}`), h('small', null, `${label} · target ${target}${unit}`));
  return h('div', { class: 'card summary' },
    h('div', { class: 'summary-head' },
      h('strong', null, rupee(t.cost)),
      h('span', null, `of ${rupee(day.budget)} daily budget · ${rupee(day.saved)} left over`)),
    h('div', { class: 'meter', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': day.budget, 'aria-valuenow': t.cost, 'aria-label': 'Budget used' },
      h('i', { style: `width:${pct}%` })),
    h('div', { class: 'stats' },
      stat('Calories', t.kcal, g.kcal, ' kcal', Math.abs(t.kcal - g.kcal) <= g.kcal * 0.1),
      stat('Protein', t.protein, g.protein, ' g', proteinOk),
      stat('Carbs', Math.round(t.carbs), g.carbs, ' g', true),
      stat('Fat', Math.round(t.fat), g.fat, ' g', true)));
}

function mealGrid(day, flashSlot) {
  return h('div', { class: 'meals' }, SLOT_ORDER.map((slot) => mealCard(day, slot, slot === flashSlot)));
}

function mealCard(day, slot, flash) {
  const m = day.slots[slot];
  const lines = m.ingredients.map((i) => h('tr', null,
    h('td', null, i.name, ' ', i.inPantry ? h('span', { class: 'have' }, 'have it') : null),
    h('td', null, fmtQty(i.qty, i.unit)),
    h('td', null, i.inPantry ? '₹0' : rupee1(i.cost))));
  const card = h('article', { class: `card meal${flash ? ' flash' : ''}`, 'data-slot': slot },
    h('div', { class: 'meal-top' },
      h('span', { class: 'slot-name' }, SLOT_LABEL[slot]),
      h('span', { class: 'price', 'aria-label': `Costs ${m.cost} rupees` }, rupee(m.cost))),
    h('h3', null, m.name),
    h('div', { class: 'facts' },
      h('span', null, h('b', null, m.kcal), ' kcal'),
      h('span', null, h('b', null, Math.round(m.protein)), ' g protein'),
      h('span', null, h('b', null, m.prep), ' min'),
      h('span', { class: `tag ${m.diet === 'nonveg' ? 'nonveg' : ''}` }, dietLabel[m.diet]),
      m.scale !== 1 ? h('span', null, `${m.scale}× portion`) : null),
    h('details', { class: 'recipe' },
      h('summary', null, 'Cost breakdown & how to cook'),
      h('table', null,
        h('tbody', null, lines),
        h('tfoot', null, h('tr', null, h('td', { colspan: 2 }, 'Meal total (rounded up)'), h('td', null, rupee(m.cost))))),
      h('p', { class: 'note' }, `You'll need: ${m.gear}`),
      h('ol', null, m.steps.map((s) => h('li', null, s)))),
    h('div', { class: 'meal-actions' },
      h('button', { class: 'btn small', type: 'button', onclick: (e) => swap(slot, e.currentTarget) }, `⇄ Swap ${SLOT_LABEL[slot].toLowerCase()}`)));
  return card;
}

function donut(title, grams, pending) {
  const kcal = [grams.protein * 4, grams.carbs * 4, grams.fat * 9];
  const total = kcal.reduce((a, b) => a + b, 0) || 1;
  const wrap = h('div', { class: 'donut' }, h('h3', null, title));
  const colors = [MACRO_COLORS.protein, MACRO_COLORS.carbs, MACRO_COLORS.fat];
  const names = ['Protein', 'Carbs', 'Fat'];
  const g = [grams.protein, grams.carbs, grams.fat].map((n) => Math.round(n));

  if (window.Chart) {
    const canvas = h('canvas', { role: 'img', 'aria-label': `${title}: protein ${g[0]} g, carbs ${g[1]} g, fat ${g[2]} g` });
    wrap.append(h('div', { class: 'canvas-box' }, canvas));
    pending.push(() => state.charts.push(new window.Chart(canvas, {
      type: 'doughnut',
      data: { labels: names, datasets: [{ data: kcal.map((k) => Math.round(k)), backgroundColor: colors, borderColor: '#fffdf8', borderWidth: 3 }] },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '62%',
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: (c) => ` ${c.label}: ${g[c.dataIndex]} g (${Math.round((kcal[c.dataIndex] / total) * 100)}% of calories)` } },
        },
      },
    })));
  } else {
    // Chart.js didn't load (offline?). Draw the same thing with CSS.
    let acc = 0;
    const stops = kcal.map((k, i) => { const s = acc; acc += (k / total) * 100; return `${colors[i]} ${s}% ${acc}%`; });
    wrap.append(h('div', { class: 'fallback', style: `background:conic-gradient(${stops.join(',')})` }));
  }
  wrap.append(h('div', { class: 'legend' }, names.map((n, i) => h('span', null, h('i', { style: `background:${colors[i]}` }), `${n} ${g[i]} g`))));
  return wrap;
}

function chartsCard(day, pending) {
  const t = day.totals, g = day.targets;
  const bar = (label, val, target, color, unit) => h('div', { class: 'bar-row' },
    h('span', null, label),
    h('div', { class: 'bar' }, h('i', { style: `width:${Math.min(100, (val / target) * 100)}%;background:${color}` })),
    h('span', null, `${Math.round(val)} / ${target} ${unit}`));
  return h('div', { class: 'card charts' },
    h('h2', null, 'Macro & calorie balance'),
    h('div', { class: 'donuts' },
      donut('Your plan', t, pending),
      donut('Your target', g, pending)),
    h('div', { class: 'bars' },
      bar('Calories', t.kcal, g.kcal, '#3c5a8a', 'kcal'),
      bar('Protein', t.protein, g.protein, MACRO_COLORS.protein, 'g'),
      bar('Carbs', t.carbs, g.carbs, MACRO_COLORS.carbs, 'g'),
      bar('Fat', t.fat, g.fat, MACRO_COLORS.fat, 'g')),
    h('p', { class: 'note', style: 'margin-top:12px' },
      `Basic RDA protein for your weight is about ${g.rdaProtein} g. Your goal target is higher because you're training.`));
}

async function savePlan() {
  const name = `${rupee(state.profile.budget)} · ${$(`input[name=goal][value="${state.profile.goal}"]`).nextElementSibling.textContent} · ${new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}`;
  const saved = store.get('platepilot.saved', []);
  saved.unshift({ name, profile: state.profile, days: state.days });
  store.set('platepilot.saved', saved.slice(0, 12));
  renderPlan();
  toast('Plan saved on this device');
  // Also keep a copy in the server's plan store (best effort).
  api('/plans', { clientId: clientId(), profile: state.profile, days: state.days.map((d) => d.pick) }).catch(() => {});
}

// -------------------------------------------------------------- grocery

async function fetchGrocery() {
  return api('/grocery', { profile: state.profile, days: state.days.map((d) => d.pick) });
}

async function loadGrocery() {
  const pane = $('#tab-grocery');
  if (!state.days.length) {
    pane.replaceChildren(h('div', { class: 'empty' }, h('h2', null, 'No plan yet'), h('p', null, 'Generate a meal plan first and your shopping list will appear here.')));
    return;
  }
  if (!state.groceryDirty && pane.childElementCount) return;
  try {
    const g = await fetchGrocery();
    state.groceryDirty = false;
    renderGrocery(pane, g);
  } catch (e) {
    pane.replaceChildren(h('div', { class: 'banner error' }, e.message));
  }
}

function renderGrocery(pane, g) {
  const n = g.days;
  const cats = g.categories.map((c) => h('section', { class: 'card cat' },
    h('h3', null, h('span', null, c.category), h('span', null, rupee(c.subtotal))),
    h('ul', null, c.items.map((i) => {
      const li = h('li', null,
        h('input', { type: 'checkbox', 'aria-label': `Got ${i.name}`, onchange: (e) => li.classList.toggle('done', e.target.checked) }),
        h('span', { class: 'name' }, i.name, ' ', h('small', null, `· need ${fmtQty(i.qty, i.unit)}`)),
        h('small', null, i.inPantry ? 'have it' : `buy ${fmtQty(i.buyQty, i.unit)}`),
        h('b', null, i.inPantry ? '₹0' : rupee(i.buyCost)));
      return li;
    }))));

  const copyText = g.categories.map((c) => `${c.category}\n${c.items.filter((i) => !i.inPantry).map((i) => `- ${i.name}: ${fmtQty(i.buyQty, i.unit)} (${rupee(i.buyCost)})`).join('\n')}`).join('\n\n');

  pane.replaceChildren(
    h('div', { class: 'pane-head' },
      h('div', null, h('h2', null, `Shopping list for ${n} day${n > 1 ? 's' : ''}`),
        h('p', null, n < 4 ? 'Short plan, so this assumes you buy loose from the kirana. Prices are estimates.' : 'Quantities are rounded up to normal pack sizes, with a small discount on bulk packs. Prices are estimates.')),
      h('button', { class: 'btn small', type: 'button', onclick: () => { navigator.clipboard?.writeText(copyText).then(() => toast('List copied'), () => toast('Could not copy')); } }, 'Copy list')),
    ...cats,
    h('div', { class: 'card totalbar' },
      h('div', null, h('div', { class: 'note' }, 'Estimated shop bill'), h('strong', null, rupee(g.buyTotal))),
      h('div', { class: 'note' }, `Food actually eaten this period costs about ${rupee(g.usedTotal)}. The rest stays in your kitchen for the next round.`)));
}

// ------------------------------------------------------------ mess mode

async function loadMess() {
  const pane = $('#tab-mess');
  const budgetInput = h('input', { type: 'number', min: 40, max: 500, step: 5, value: state.messBudget, 'aria-label': 'Outside spend per day', style: 'max-width:90px' });
  const run = async () => {
    state.messBudget = Math.max(40, Number(budgetInput.value) || 40);
    try {
      const res = await api('/mess', { profile: { ...readProfile(), budget: state.messBudget } });
      renderMess(pane, res, budgetInput, run);
    } catch (e) {
      pane.replaceChildren(h('div', { class: 'banner error' }, e.message));
    }
  };
  await run();
}

function renderMess(pane, res, budgetInput, rerun) {
  const t = res.totals, g = res.targets;
  pane.replaceChildren(
    h('div', { class: 'pane-head' },
      h('div', null, h('h2', null, 'Hostel mess mode'),
        h('p', null, 'Already paying for the mess? Pick the best dishes from a typical menu, then top up with cheap protein from outside.')),
      h('div', { class: 'group', style: 'display:flex;gap:8px;align-items:center' },
        h('label', { class: 'note' }, 'Outside spend ₹'), budgetInput,
        h('button', { class: 'btn small', type: 'button', onclick: rerun }, 'Update'))),
    h('div', { class: 'mess-grid' }, ['breakfast', 'lunch', 'dinner'].map((s) => h('div', { class: 'card' },
      h('span', { class: 'slot-name' }, `Pick at mess · ${SLOT_LABEL[s]}`),
      h('h3', { style: 'margin:6px 0' }, res.mess[s].name),
      h('div', { class: 'facts' }, h('span', null, h('b', null, res.mess[s].kcal), ' kcal'), h('span', null, h('b', null, res.mess[s].protein), ' g protein'))))),
    h('div', { class: 'card supp' },
      h('h3', null, res.supplements.length ? 'Buy outside to fill the gap' : 'No top-up needed'),
      res.supplements.length
        ? h('ul', null, res.supplements.map((s) => h('li', null, h('span', null, s.count > 1 ? `${s.count} × ${s.label}` : s.label), h('span', null, `${rupee(s.cost)} · ${Math.round(s.protein)} g protein`))))
        : h('p', { class: 'note' }, 'The mess menu already covers your targets.')),
    h('div', { class: 'card summary' },
      h('div', { class: 'summary-head' }, h('strong', null, rupee(t.cost)), h('span', null, `outside spend of ${rupee(res.budget)} limit`)),
      h('div', { class: 'stats' },
        h('div', { class: 'stat' }, h('b', null, `${t.kcal} kcal`), h('small', null, `target ${g.kcal}`)),
        h('div', { class: `stat ${t.protein >= g.protein * 0.9 ? 'ok' : 'low'}` }, h('b', null, `${t.protein} g`), h('small', null, `protein · target ${g.protein}`)),
        h('div', { class: 'stat' }, h('b', null, `${Math.round(t.carbs)} g`), h('small', null, `carbs · target ${g.carbs}`)),
        h('div', { class: 'stat' }, h('b', null, `${Math.round(t.fat)} g`), h('small', null, `fat · target ${g.fat}`)))),
    h('p', { class: 'note' }, 'Mess nutrition is a ballpark for a standard serving. Menus differ, so treat this as a guide.'));
}

// ------------------------------------------------------------ community

async function loadCommunity() {
  const pane = $('#tab-community');
  try {
    const { posts } = await api('/community');
    renderCommunity(pane, posts);
  } catch (e) {
    pane.replaceChildren(h('div', { class: 'banner error' }, e.message));
  }
}

function renderCommunity(pane, posts) {
  const ingName = Object.fromEntries(state.meta.ingredients.map((i) => [i.id, i]));
  const items = [];
  const list = h('ul', { class: 'items-list' });
  const select = h('select', { 'aria-label': 'Ingredient' }, state.meta.ingredients.map((i) => h('option', { value: i.id }, `${i.name} (${i.unit})`)));
  const qty = h('input', { type: 'number', min: 1, max: 1000, placeholder: 'Qty', 'aria-label': 'Quantity' });
  const title = h('input', { type: 'text', maxlength: 80, placeholder: 'e.g. Kettle masala oats', 'aria-label': 'Recipe title' });
  const author = h('input', { type: 'text', maxlength: 30, placeholder: 'Your name (optional)', 'aria-label': 'Your name' });
  const steps = h('textarea', { maxlength: 600, placeholder: 'How do you make it? Keep it dorm-room simple.', 'aria-label': 'Steps' });
  const err = h('p', { class: 'form-error', hidden: true, role: 'alert' });

  const redraw = () => {
    list.replaceChildren(...items.map((it, idx) => h('li', null, `${ingName[it.id].name} ${it.qty}${ingName[it.id].unit === 'pc' ? ' pc' : ingName[it.id].unit}`,
      h('button', { type: 'button', 'aria-label': 'Remove', onclick: () => { items.splice(idx, 1); redraw(); } }, '×'))));
  };

  const form = h('form', { class: 'card add-form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    err.hidden = true;
    try {
      await api('/community', { title: title.value, author: author.value, steps: steps.value, items });
      toast('Recipe posted. Thanks!');
      loadCommunity();
    } catch (ex) { err.textContent = ex.message; err.hidden = false; }
  } },
    h('h3', null, 'Share a dorm-room hack'),
    h('p', { class: 'note' }, 'Cost and nutrition are worked out from the shared price table, so every recipe on the board has a checkable price.'),
    h('div', { class: 'row', style: 'grid-template-columns:1fr 1fr' }, title, author),
    h('div', { class: 'row' }, select, qty,
      h('button', { class: 'btn small', type: 'button', onclick: () => {
        const q = Number(qty.value);
        if (!q || q <= 0) { toast('Enter a quantity first'); return; }
        if (items.length >= 12) { toast('That is plenty of ingredients'); return; }
        items.push({ id: select.value, qty: q }); qty.value = ''; redraw();
      } }, 'Add')),
    list, steps, err,
    h('div', { style: 'margin-top:10px' }, h('button', { class: 'btn small', type: 'submit' }, 'Post recipe')));

  const cards = posts.map((p) => h('article', { class: 'card post' },
    h('div', { class: 'post-top' },
      h('div', null, h('h3', null, p.title), h('span', { class: 'by' }, `by ${p.author}`)),
      h('span', { class: 'price' }, rupee(p.cost))),
    h('p', null, p.steps),
    h('div', { class: 'chips' }, p.items.map((i) => h('span', null, `${ingName[i.id] ? ingName[i.id].name : i.id} ${i.qty}`)), ' '),
    h('div', { class: 'facts', style: 'margin-top:8px' },
      h('span', null, h('b', null, p.kcal), ' kcal'), h('span', null, h('b', null, Math.round(p.protein)), ' g protein'),
      h('span', { class: `tag ${p.diet === 'nonveg' ? 'nonveg' : ''}` }, dietLabel[p.diet]),
      h('span', { class: 'verified' }, 'cost checked against price table')),
    h('div', { class: 'meal-actions' }, h('button', { class: 'btn small', type: 'button', onclick: async (e) => {
      e.currentTarget.disabled = true;
      try { await api(`/community/${p.id}/upvote`, {}); loadCommunity(); } catch (ex) { toast(ex.message); }
    } }, `▲ ${p.upvotes}`))));

  pane.replaceChildren(
    h('div', { class: 'pane-head' }, h('div', null, h('h2', null, 'Community budget recipes'), h('p', null, 'Cheap, filling dorm-room meals from other students.'))),
    form, ...cards);
}

// -------------------------------------------------------- printable sheet

async function printSheet() {
  if (!state.days.length) { toast('Generate a plan first'); return; }
  if (state.days.length < 7) {
    toast('Building a full 7-day plan for the sheet…');
    $('input[name=days][value="7"]').checked = true;
    await generate({ keepSeed: true });
    if (state.days.length < 7) return;
  }
  let g;
  try { g = await fetchGrocery(); } catch (e) { toast(e.message); return; }

  const sheet = $('#printSheet');
  const p = state.profile;
  const grid = h('div', { class: 'ps-grid' }, state.days.map((d, i) => h('div', { class: 'ps-day' },
    h('h2', null, h('span', null, `Day ${i + 1}`), h('span', null, `${rupee(d.totals.cost)} · ${d.totals.kcal} kcal · ${Math.round(d.totals.protein)} g protein`)),
    SLOT_ORDER.map((s) => {
      const m = d.slots[s];
      return h('div', { class: 'ps-meal' },
        h('b', null, `${SLOT_LABEL[s]}: ${m.name} (${rupee(m.cost)})`),
        h('p', null, m.ingredients.map((x) => `${x.name} ${fmtQty(x.qty, x.unit)}`).join(', ')),
        h('p', null, m.steps.join(' ')));
    }))));
  const groc = h('div', { class: 'ps-groc' },
    h('h2', null, `Grocery list · about ${rupee(g.buyTotal)}`),
    h('ul', null, g.categories.flatMap((c) => c.items.filter((i) => !i.inPantry).map((i) => h('li', null, `☐ ${i.name} ${fmtQty(i.buyQty, i.unit)} (${rupee(i.buyCost)})`)))));
  sheet.replaceChildren(
    h('div', { class: 'ps-head' }, h('h1', null, 'PlatePilot weekly plan'), h('span', null, `${rupee(p.budget)}/day · ${$(`input[name=goal][value="${p.goal}"]`).nextElementSibling.textContent} · ${$(`input[name=diet][value="${p.diet}"]`).nextElementSibling.textContent}`)),
    grid, groc,
    h('div', { class: 'ps-foot' }, 'Prices are estimates. Stick this on the fridge.'));
  window.print();
}

// ----------------------------------------------------------------- tabs

function setTab(name) {
  state.tab = name;
  $$('.tab').forEach((t) => {
    const on = t.dataset.tab === name;
    t.classList.toggle('is-active', on);
    t.setAttribute('aria-selected', on ? 'true' : 'false');
  });
  $$('.tabpane').forEach((p) => { p.hidden = p.id !== `tab-${name}`; });
  if (name === 'grocery') loadGrocery();
  if (name === 'mess') loadMess();
  if (name === 'community') loadCommunity();
}

// ----------------------------------------------------------------- init

async function init() {
  try {
    state.meta = await api('/meta');
  } catch (e) {
    toast('Could not reach the PlatePilot server.');
    return;
  }
  buildPantry();

  const budget = $('#budget'), range = $('#budgetRange');
  range.addEventListener('input', () => { budget.value = range.value; });
  budget.addEventListener('input', () => { range.value = Math.min(300, Math.max(60, Number(budget.value) || 120)); });
  $('#priceMult').addEventListener('input', (e) => { $('#priceOut').textContent = `${e.target.value}%`; });
  $('#profileForm').addEventListener('submit', (e) => { e.preventDefault(); generate(); });
  $$('.tab').forEach((t) => t.addEventListener('click', () => setTab(t.dataset.tab)));

  const form = store.get('platepilot.form', null);
  if (form) writeProfile(form);
  const last = store.get('platepilot.last', null);
  if (last && last.days && last.days.length) {
    state.profile = last.profile; state.days = last.days; state.seed = last.seed || 1;
    renderPlan();
  }
}

init();
