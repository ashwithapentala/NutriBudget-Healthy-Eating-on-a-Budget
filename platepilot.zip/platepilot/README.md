# PlatePilot

A budget-aware diet planner for college students. You give it a daily food budget in rupees, a diet (vegetarian, non-veg, vegan) and a goal (weight loss, maintenance, muscle gain). It gives back breakfast, lunch, snack and dinner that hit your calories and protein without going over budget.

Built for the NutriNinja Cup hackathon brief.

## Run it

```bash
npm install
npm start
# open http://localhost:3000
```

Needs Node 18 or newer. Run the tests with `npm test`.

## What's in it

**Must-haves from the brief**
- Profile form: budget, diet, goal (plus body weight, optional calorie target, local price slider)
- Budget-constrained generator (multiple-choice knapsack, described below)
- Doughnut charts (Chart.js) for protein / carbs / fat, your plan vs your target
- Per-meal cost breakdown and hostel-friendly cooking steps
- Consolidated grocery list by category with estimated shop prices
- One-click swap that finds a nutritionally close, budget-safe alternative
- localStorage persistence, plus saved plans

**Stretch features**
- Hostel mess mode: picks from a typical mess menu and tops up with cheap protein
- Pantry optimizer: tick what you already own and it is treated as free
- Printable 7-day fridge sheet (uses the browser's Print dialog, so "Save as PDF" works too)
- Community recipe board with server-side cost calculation

## How the optimizer works

1. 50 meals are defined purely as ingredient lists (`src/data/meals.js`). Cost, calories and macros are derived from one ingredient price table (`src/data/ingredients.js`), so numbers can't drift out of sync.
2. Each meal can be served at 4 portion sizes (0.75x to 1.5x), so each slot has a few hundred options.
3. For each slot the most promising options are shortlisted by fit to calorie and protein targets per rupee.
4. Every combination of the shortlists is searched with cost pruning. The best-scoring day under the budget wins. Protein shortfall is penalised hardest.
5. Hard variety rules: no repeated dish in a day, and neighbouring meals never share a main protein or carb source. Across a week, dishes already used are penalised, so the week doesn't repeat itself.

Costs are rounded up per meal, so the totals on screen can never add up to more than your budget.

Targets: maintenance = 33 kcal per kg body weight, goal adjusts it (-400 / 0 / +300). Protein is 1.6 / 1.2 / 1.8 g per kg. Fat is about 25-28% of calories, the rest is carbs. The basic RDA of 0.8 g per kg is shown for reference.

## Limits to know about

- Prices are estimates, not live market data. That is what the price slider is for.
- Nutrition values are standard approximations. This is a planning aid, not medical advice. Check with a doctor or dietitian for any health condition.
- Very low budgets work but come with warnings. Below about ₹47-53 a day the app tells you it can't build four balanced meals.
- Eggs count as non-veg, so "Vegetarian" is vegetarian in the Indian sense.

## Layout

```
server.js            Express app and routes
src/engine.js        targets, optimizer, swap, grocery, mess mode
src/api.js           request handlers (testable without a server)
src/store.js         JSON-file database
src/data/            ingredients, 50 meals, mess menu
public/              index.html, style.css, app.js
test/                node:test suite
```
