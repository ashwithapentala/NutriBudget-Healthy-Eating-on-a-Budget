'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');

process.env.PLATEPILOT_DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'platepilot-'));

const engine = require('../src/engine');
const { api, ApiError } = require('../src/api');

const SLOTS = engine.SLOTS;
const clashes = (a, b) =>
  (a.pk !== 'none' && a.pk === b.pk) || (a.ck !== 'none' && a.ck === b.ck);

test('dataset has 50 meals with valid ingredients and sane nutrition', () => {
  assert.equal(engine.MEALS.length, 50);
  const ids = new Set(engine.MEALS.map((m) => m.id));
  assert.equal(ids.size, 50, 'meal ids are unique');
  for (const r of engine.searchRecipes()) {
    assert.ok(r.kcal >= 100 && r.kcal <= 900, `${r.name} kcal ${r.kcal}`);
    assert.ok(r.cost >= 2 && r.cost <= 80, `${r.name} cost ${r.cost}`);
  }
});

test('every diet has meals for every slot', () => {
  for (const diet of ['vegan', 'vegetarian', 'nonveg']) {
    for (const slot of SLOTS) {
      assert.ok(engine.searchRecipes({ diet, slot }).length >= 4, `${diet}/${slot}`);
    }
  }
});

test('demo: ₹120 muscle-gain plan at 2200 kcal is high-protein and under budget', () => {
  for (const diet of ['vegetarian', 'nonveg', 'vegan']) {
    const { days, targets } = engine.generatePlan({
      budget: 120, diet, goal: 'muscle_gain', kcalOverride: 2200,
    });
    const t = days[0].totals;
    assert.ok(t.cost <= 120, `${diet} cost ${t.cost}`);
    assert.ok(Math.abs(t.kcal - 2200) <= 220, `${diet} kcal ${t.kcal}`);
    assert.ok(t.protein >= targets.protein * 0.9, `${diet} protein ${t.protein}`);
  }
});

test('plans never exceed the budget across diets, goals and budgets', () => {
  for (const diet of ['vegan', 'vegetarian', 'nonveg']) {
    for (const goal of Object.keys(engine.GOALS)) {
      for (const budget of [70, 100, 150, 250]) {
        let plan;
        try {
          plan = engine.generatePlan({ budget, diet, goal, days: 3 });
        } catch (e) {
          assert.ok(e instanceof engine.InputError);
          continue;
        }
        for (const d of plan.days) {
          assert.ok(d.totals.cost <= budget, `${diet}/${goal}/${budget}: ${d.totals.cost}`);
          const sum = SLOTS.reduce((s, k) => s + d.slots[k].cost, 0);
          assert.equal(sum, d.totals.cost);
        }
      }
    }
  }
});

test('diet rules are respected', () => {
  const vegan = engine.generatePlan({ budget: 120, diet: 'vegan', days: 7 });
  const veg = engine.generatePlan({ budget: 120, diet: 'vegetarian', days: 7 });
  for (const d of vegan.days) for (const s of SLOTS) assert.equal(d.slots[s].diet, 'vegan');
  for (const d of veg.days) {
    for (const s of SLOTS) {
      assert.notEqual(d.slots[s].diet, 'nonveg');
      assert.ok(!d.slots[s].ingredients.some((i) => i.id === 'egg' || i.id === 'chicken'));
    }
  }
});

test('variety: no repeats in a day, no adjacent shared protein or carb source', () => {
  const plan = engine.generatePlan({ budget: 110, diet: 'nonveg', goal: 'maintenance', days: 7, seed: 9 });
  for (const d of plan.days) {
    const ids = SLOTS.map((s) => d.slots[s].id);
    assert.equal(new Set(ids).size, 4);
    for (let i = 1; i < SLOTS.length; i++) {
      assert.ok(!clashes(engine.MEAL_BY_ID[ids[i - 1]], engine.MEAL_BY_ID[ids[i]]), ids.join(','));
    }
  }
  // Across the week we should see real variety, not the same 4 dishes.
  const unique = new Set(plan.days.flatMap((d) => SLOTS.map((s) => d.slots[s].id)));
  assert.ok(unique.size >= 16, `only ${unique.size} distinct dishes in a week`);
});

test('too-low budget gives a clear error with the minimum needed', () => {
  assert.throws(() => engine.generatePlan({ budget: 40, priceMult: 1.6 }), /too low/);
  // At ₹40 the plan still works, but it must warn about low calories / protein.
  const tight = engine.generatePlan({ budget: 40 }).days[0];
  assert.ok(tight.totals.cost <= 40);
  assert.ok(tight.warnings.length > 0);
  assert.throws(() => engine.generatePlan({ budget: 5 }), /between/);
  assert.throws(() => engine.generatePlan({ diet: 'carnivore' }), /Diet/);
});

test('swap keeps the day inside the budget and changes only that slot', () => {
  const profile = { budget: 120, diet: 'vegetarian', goal: 'muscle_gain', kcalOverride: 2200 };
  const { days } = engine.generatePlan(profile);
  const before = days[0];
  const res = engine.swapMeal(profile, before.pick, 'breakfast');
  assert.notEqual(res.day.slots.breakfast.id, before.slots.breakfast.id);
  assert.ok(res.day.totals.cost <= 120);
  for (const s of ['lunch', 'snack', 'dinner']) {
    assert.equal(res.day.slots[s].id, before.slots[s].id);
  }
  // Swapped dish is a nutritional near-match.
  const a = before.slots.breakfast, b = res.day.slots.breakfast;
  assert.ok(Math.abs(a.kcal - b.kcal) / a.kcal < 0.35, `${a.kcal} vs ${b.kcal}`);
  // Repeated swaps with an exclude list cycle through different dishes.
  const seen = [before.slots.breakfast.id, res.day.slots.breakfast.id];
  let cur = res.day;
  for (let i = 0; i < 4; i++) {
    cur = engine.swapMeal(profile, cur.pick, 'breakfast', seen).day;
    assert.ok(!seen.includes(cur.slots.breakfast.id));
    seen.push(cur.slots.breakfast.id);
  }
});

test('swap respects a vegetarian profile', () => {
  const profile = { budget: 120, diet: 'vegetarian', goal: 'muscle_gain' };
  const { days } = engine.generatePlan(profile);
  for (const slot of SLOTS) {
    const r = engine.swapMeal(profile, days[0].pick, slot);
    assert.notEqual(r.day.slots[slot].diet, 'nonveg');
  }
});

test('grocery list adds up and covers every ingredient used', () => {
  const profile = { budget: 110, diet: 'vegetarian', goal: 'maintenance', days: 7 };
  const { days } = engine.generatePlan(profile);
  const g = engine.buildGrocery(days.map((d) => d.pick), profile);
  assert.equal(g.categories.reduce((s, c) => s + c.subtotal, 0), g.buyTotal);
  const listed = new Set(g.categories.flatMap((c) => c.items.map((i) => i.id)));
  for (const d of days) {
    for (const s of SLOTS) for (const ing of d.slots[s].ingredients) assert.ok(listed.has(ing.id), ing.id);
  }
  assert.ok(g.buyTotal >= g.usedTotal);
});

test('pantry items cost nothing and are skipped on the grocery list', () => {
  const base = { budget: 100, diet: 'vegetarian', goal: 'maintenance' };
  const withPantry = { ...base, pantry: ['rice', 'atta', 'oil'] };
  const a = engine.generatePlan(base).days[0];
  const b = engine.generatePlan(withPantry).days[0];
  assert.ok(b.totals.cost < a.totals.cost);
  const g = engine.buildGrocery([b.pick], withPantry);
  const rice = g.categories.flatMap((c) => c.items).find((i) => i.id === 'rice');
  if (rice) assert.equal(rice.buyCost, 0);
});

test('price slider scales costs', () => {
  const cheap = engine.generatePlan({ budget: 200, priceMult: 0.8, seed: 3 }).days[0];
  const dear = engine.generatePlan({ budget: 200, priceMult: 1.4, seed: 3 }).days[0];
  assert.ok(dear.totals.cost > cheap.totals.cost);
});

test('same seed gives the same plan, a different seed can differ', () => {
  const p = { budget: 120, diet: 'vegetarian', seed: 5 };
  const a = engine.generatePlan(p).days[0].pick;
  const b = engine.generatePlan(p).days[0].pick;
  assert.deepEqual(a, b);
});

test('mess mode fills the protein gap with cheap supplements inside budget', () => {
  const r = engine.messPlan({ budget: 40, diet: 'vegetarian', goal: 'muscle_gain' });
  assert.ok(r.totals.cost <= 40);
  assert.ok(r.totals.protein > 60);
  for (const s of ['breakfast', 'lunch', 'dinner']) assert.ok(r.mess[s].name);
  const vegan = engine.messPlan({ budget: 40, diet: 'vegan' });
  for (const s of ['breakfast', 'lunch', 'dinner']) assert.equal(vegan.mess[s].diet, 'vegan');
});

test('API: validation errors become 400s', () => {
  assert.throws(() => api.plan({ budget: 5 }), (e) => e instanceof ApiError && e.status === 400);
  assert.throws(() => api.swap({}), (e) => e.status === 400);
  assert.throws(() => api.grocery({ days: [] }), (e) => e.status === 400);
});

test('API: community board prices recipes server-side and supports upvotes', () => {
  const list = api.communityList();
  assert.ok(list.posts.length >= 3);
  const seedId = list.posts[0].id;
  const before = list.posts[0].upvotes;
  assert.equal(api.communityUpvote(seedId).upvotes, before + 1);

  const { post } = api.communityAdd({
    title: 'Egg bhurji toast', author: 'Asha', steps: 'Scramble eggs, pile on toast.',
    items: [{ id: 'egg', qty: 2 }, { id: 'bread', qty: 2 }], cost: 1, // fake cost is ignored
  });
  assert.equal(post.cost, 21);
  assert.equal(post.diet, 'nonveg');
  assert.throws(() => api.communityAdd({ title: 'x', steps: 'short' }), (e) => e.status === 400);
  assert.throws(
    () => api.communityAdd({ title: 'Bad', steps: 'long enough text', items: [{ id: 'nope', qty: 5 }] }),
    (e) => e.status === 400,
  );
  assert.throws(() => api.communityUpvote('missing'), (e) => e.status === 404);
});

test('API: plans can be saved and listed per client', () => {
  const profile = { budget: 100, diet: 'vegetarian', goal: 'maintenance' };
  const { days } = api.plan(profile);
  const saved = api.savePlan({ clientId: 'abc', profile, days: days.map((d) => d.pick) });
  assert.ok(saved.id);
  assert.equal(api.listPlans({ clientId: 'abc' }).plans.length, 1);
  assert.equal(api.listPlans({ clientId: 'someone-else' }).plans.length, 0);
  assert.throws(
    () => api.savePlan({ clientId: 'abc', profile, days: [{ slots: { breakfast: { id: 'nope' } } }] }),
    (e) => e.status === 400,
  );
});
