'use strict';

const path = require('path');
const express = require('express');
const { api, ApiError } = require('./src/api');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '200kb' }));

// Wrap a handler so thrown ApiErrors become clean JSON responses.
const route = (fn) => (req, res, next) => {
  try {
    res.json(fn(req));
  } catch (err) {
    next(err);
  }
};

app.get('/api/meta', route(() => api.meta()));
app.get('/api/recipes', route((req) => api.recipes(req.query)));
app.post('/api/plan', route((req) => api.plan(req.body)));
app.post('/api/swap', route((req) => api.swap(req.body)));
app.post('/api/grocery', route((req) => api.grocery(req.body)));
app.post('/api/mess', route((req) => api.mess(req.body)));
app.get('/api/plans', route((req) => api.listPlans(req.query)));
app.post('/api/plans', route((req) => api.savePlan(req.body)));
app.get('/api/community', route(() => api.communityList()));
app.post('/api/community', route((req) => api.communityAdd(req.body)));
app.post('/api/community/:id/upvote', route((req) => api.communityUpvote(req.params.id)));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use(express.static(path.join(__dirname, 'public')));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err instanceof ApiError) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Bad JSON.' });
  console.error(err);
  res.status(500).json({ error: 'Something went wrong on our side.' });
});

const PORT = process.env.PORT || 3000;
if (require.main === module) {
  app.listen(PORT, () => console.log(`PlatePilot running on http://localhost:${PORT}`));
}

module.exports = app;
