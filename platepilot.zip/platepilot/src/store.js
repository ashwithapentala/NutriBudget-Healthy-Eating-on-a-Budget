'use strict';

/*
 * Tiny JSON-file store (the brief allows "SQLite / Local JSON Store").
 * Collections: studentBudgets, mealPlans, communityRecipes.
 * Writes go to a temp file first and are then renamed, so a crash mid-write
 * can't leave a half-written database behind.
 */

const fs = require('fs');
const path = require('path');

const EMPTY = { studentBudgets: [], mealPlans: [], communityRecipes: [] };
let cache = null;
let cachePath = null;

function dbPath() {
  const dir = process.env.PLATEPILOT_DATA || path.join(__dirname, '..', 'data');
  return path.join(dir, 'db.json');
}

function load() {
  const file = dbPath();
  if (cache && cachePath === file) return cache;
  cachePath = file;
  try {
    cache = { ...EMPTY, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
  } catch {
    cache = JSON.parse(JSON.stringify(EMPTY));
  }
  return cache;
}

function save() {
  const file = dbPath();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(cache, null, 2));
  fs.renameSync(tmp, file);
}

function collection(name) {
  return load()[name];
}

function insert(name, doc, cap = 500) {
  const list = load()[name];
  list.push(doc);
  if (list.length > cap) list.splice(0, list.length - cap); // keep it bounded
  save();
  return doc;
}

function update(name, id, fn) {
  const doc = load()[name].find((d) => d.id === id);
  if (!doc) return null;
  fn(doc);
  save();
  return doc;
}

module.exports = { collection, insert, update };
