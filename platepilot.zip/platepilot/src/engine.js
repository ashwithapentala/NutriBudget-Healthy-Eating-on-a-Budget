'use strict';

/*
 * PlatePilot engine: targets, cost maths, the budget optimizer, swaps,
 * grocery list and hostel-mess mode. Pure functions, no I/O, so it is easy
 * to test and reason about.
 *
 * How the optimizer works (a multiple-choice knapsack):
 *   - Each of the 4 slots (breakfast, lunch, snack, dinner) is a "group".
 *     We must choose exactly one (meal, portion size) option from each group.
 *   - Every option has a cost in rupees. The sum must stay under the daily budget.
 *   - Value is how close the whole day lands on calorie / protein / carb / fat
 *     targets, with a heavy penalty on missing protein.
 *   - Per slot we first shortlist the most promising options (ranked by
 *     protein-per-rupee style fit), then search every combination of the
 *     shortlists with cost pruning. Exhaustive search over a small shortlist
 *     gives the best answer, where a plain greedy pass can get stuck.
 *   - Variety is a hard rule: neighbouring meals never share a main protein
 *     or main carb source, and no dish is repeated on the same day.
 */

const { INGREDIENTS } = require('./data/ingredients');
const { MEALS, DIET_RANK } = require('./data/meals');
const { MESS_MENU } = require('./data/mess');

const SLOTS = ['breakfast', 'lunch', 'snack', 'dinner'];
const SLOT_LETTER = { breakfast: 'b', lunch: 'l', snack: 's', dinner: 'd' };
const SLOT_SHARE = { breakfast: 0.25, lunch: 0.33, snack: 0.12, dinner: 0.30 };
const SCALES = [0.75, 1, 1.25, 1.5];
const SHORTLIST = 16;

const GOALS = {
  weight_loss: { label: 'Weight Loss',  kcalDelta: -400, proteinPerKg: 1.6, fatShare: 0.25 },
  maintenance: { label: 'Maintenance',  kcalDelta: 0,    proteinPerKg: 1.2, fatShare: 0.28 },
  muscle_gain: { label: 'Muscle Gain',  kcalDelta: 300,  proteinPerKg: 1.8, fatShare: 0.25 },
};
const DIETS = { vegan: 0, vegetarian: 1, nonveg: 2 };

const MEAL_BY_ID = Object.fromEntries(MEALS.map((m) => [m.id, m]));

const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
const round1 = (n) => Math.round(n * 10) / 10;

class InputError extends Error {}

// ---------------------------------------------------------------- profile

function normalizeProfile(raw = {}) {
  const num = (v, def) => (v === undefined || v === null || v === '' ? def : Number(v));

  const budget = num(raw.budget, 120);
  if (!Number.isFinite(budget) || budget < 40 || budget > 2000) {
    throw new InputError('Daily budget must be between ₹40 and ₹2000.');
  }
  const diet = raw.diet || 'vegetarian';
  if (!(diet in DIETS)) throw new InputError('Diet must be vegetarian, vegan or nonveg.');
  const goal = raw.goal || 'maintenance';
  if (!(goal in GOALS)) throw new InputError('Goal must be weight_loss, muscle_gain or maintenance.');

  const weightKg = num(raw.weightKg, 65);
  if (!Number.isFinite(weightKg) || weightKg < 35 || weightKg > 160) {
    throw new InputError('Body weight must be between 35 and 160 kg.');
  }
  let kcalOverride = null;
  if (raw.kcalOverride !== undefined && raw.kcalOverride !== null && raw.kcalOverride !== '') {
    kcalOverride = Number(raw.kcalOverride);
    if (!Number.isFinite(kcalOverride) || kcalOverride < 1200 || kcalOverride > 4500) {
      throw new InputError('Calorie target must be between 1200 and 4500.');
    }
  }
  const priceMult = clamp(num(raw.priceMult, 1) || 1, 0.6, 1.6);
  const pantry = Array.isArray(raw.pantry) ? raw.pantry.filter((id) => INGREDIENTS[id]) : [];
  const days = clamp(Math.round(num(raw.days, 1)) || 1, 1, 7);
  const seed = Math.round(num(raw.seed, 1)) || 1;

  return { budget, diet, goal, weightKg, kcalOverride, priceMult, pantry, days, seed };
}

function computeTargets(profile) {
  const goal = GOALS[profile.goal];
  const maintenance = 33 * profile.weightKg;
  const kcal = profile.kcalOverride || Math.round((maintenance + goal.kcalDelta) / 50) * 50;
  const protein = Math.round(goal.proteinPerKg * profile.weightKg);
  const fat = Math.round((kcal * goal.fatShare) / 9);
  const carbs = Math.max(0, Math.round((kcal - protein * 4 - fat * 9) / 4));
  return {
    kcal, protein, carbs, fat,
    rdaProtein: Math.round(0.8 * profile.weightKg), // baseline RDA, 0.8 g/kg
  };
}

// ------------------------------------------------------------ meal maths

function makeCtx(profile) {
  return { mult: profile.priceMult, pantry: new Set(profile.pantry), diet: profile.diet };
}

function scaleQty(ing, qty, scale) {
  if (ing.fixed || scale === 1) return qty;
  if (ing.unit === 'pc') return Math.max(1, Math.round(qty * scale));
  return Math.max(5, Math.round((qty * scale) / 5) * 5);
}

// Nutrition + cost for one meal at one portion scale.
function evalMeal(meal, scale, ctx) {
  const lines = [];
  let kcal = 0, protein = 0, carbs = 0, fat = 0, rawCost = 0;
  for (const [id, base] of meal.ingredients) {
    const ing = INGREDIENTS[id];
    const qty = scaleQty(ing, base, scale);
    const f = qty / ing.per;
    kcal += ing.kcal * f;
    protein += ing.protein * f;
    carbs += ing.carbs * f;
    fat += ing.fat * f;
    const have = ctx.pantry.has(id);
    const cost = have ? 0 : ing.price * f * ctx.mult;
    rawCost += cost;
    lines.push({ id, name: ing.name, qty, unit: ing.unit, cost: round1(cost), inPantry: have });
  }
  return {
    lines,
    kcal: Math.round(kcal),
    protein: round1(protein),
    carbs: round1(carbs),
    fat: round1(fat),
    // Round UP so the displayed totals can never add up to more than the budget.
    cost: Math.ceil(rawCost - 1e-9),
  };
}

function dietAllowed(mealDiet, userDiet) {
  return DIET_RANK[mealDiet] <= DIETS[userDiet];
}

function mealsFor(slot, diet) {
  const letter = SLOT_LETTER[slot];
  return MEALS.filter((m) => m.slots.includes(letter) && dietAllowed(m.diet, diet));
}

function clash(a, b) {
  return (a.pk !== 'none' && a.pk === b.pk) || (a.ck !== 'none' && a.ck === b.ck);
}

// Small seeded RNG so "regenerate" gives a different but reproducible plan.
function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ------------------------------------------------------------- optimizer

function buildCandidates(profile, targets, ctx, history, rng) {
  const cands = {};
  for (const slot of SLOTS) {
    const share = SLOT_SHARE[slot];
    const slotKcal = targets.kcal * share;
    const slotProtein = targets.protein * share;
    const options = [];
    for (const meal of mealsFor(slot, profile.diet)) {
      SCALES.forEach((scale) => {
        const e = evalMeal(meal, scale, ctx);
        if (e.cost > profile.budget) return;
        const kcalGap = Math.abs(e.kcal - slotKcal) / slotKcal;
        const proteinGap = Math.max(0, slotProtein - e.protein) / Math.max(slotProtein, 1);
        const used = history.usage[meal.id] || 0;
        const sameAsYesterday = history.prev && history.prev[slot] === meal.id ? 0.4 : 0;
        const fit = 1.5 * kcalGap + 2 * proteinGap
          + 0.4 * (e.cost / (profile.budget * share))
          + 0.12 * used + sameAsYesterday + rng() * 0.05;
        options.push({ meal, scale, e, fit });
      });
    }
    options.sort((a, b) => a.fit - b.fit);

    // Take the best few, but at most 2 portion sizes of any one dish.
    const chosen = [];
    const perMeal = {};
    for (const o of options) {
      if ((perMeal[o.meal.id] || 0) >= 2) continue;
      chosen.push(o);
      perMeal[o.meal.id] = (perMeal[o.meal.id] || 0) + 1;
      if (chosen.length >= SHORTLIST) break;
    }
    // Always keep the three cheapest options so tight budgets stay solvable.
    const cheapest = [...options].sort((a, b) => a.e.cost - b.e.cost).slice(0, 3);
    for (const o of cheapest) if (!chosen.includes(o)) chosen.push(o);
    cands[slot] = chosen;
  }
  return cands;
}

function scoreDay(pick, targets, budget, history) {
  let kcal = 0, protein = 0, carbs = 0, fat = 0, cost = 0;
  for (const c of pick) {
    kcal += c.e.kcal; protein += c.e.protein; carbs += c.e.carbs; fat += c.e.fat; cost += c.e.cost;
  }
  const kcalErr = Math.abs(kcal - targets.kcal) / targets.kcal;
  const proteinPen = protein < targets.protein
    ? ((targets.protein - protein) / targets.protein) * 6
    : Math.max(0, (protein - 1.35 * targets.protein) / targets.protein) * 0.6;
  const fatErr = Math.abs(fat - targets.fat) / Math.max(targets.fat, 1);
  const carbErr = Math.abs(carbs - targets.carbs) / Math.max(targets.carbs, 1);

  // Same main protein showing up twice in a day (not adjacent) is a soft penalty.
  let repeats = 0;
  for (let i = 0; i < pick.length; i++) {
    for (let j = i + 1; j < pick.length; j++) {
      if (pick[i].meal.pk !== 'none' && pick[i].meal.pk === pick[j].meal.pk) repeats++;
    }
  }
  let hist = 0;
  for (const c of pick) hist += 0.1 * (history.usage[c.meal.id] || 0);

  return -(3 * kcalErr + proteinPen + 0.5 * fatErr + 0.7 * carbErr
    + 0.2 * (cost / budget) + 0.15 * repeats + hist);
}

function searchDay(cands, targets, budget, history, strict) {
  const minCost = SLOTS.map((s) => Math.min(...cands[s].map((c) => c.e.cost)));
  const minAfter = new Array(SLOTS.length + 1).fill(0);
  for (let i = SLOTS.length - 1; i >= 0; i--) minAfter[i] = minAfter[i + 1] + minCost[i];

  let best = null;
  let bestScore = -Infinity;
  const pick = new Array(SLOTS.length);

  const rec = (i, cost) => {
    if (i === SLOTS.length) {
      const s = scoreDay(pick, targets, budget, history);
      if (s > bestScore) { bestScore = s; best = pick.slice(); }
      return;
    }
    for (const c of cands[SLOTS[i]]) {
      if (cost + c.e.cost + minAfter[i + 1] > budget) continue;
      if (i > 0 && strict && clash(pick[i - 1].meal, c.meal)) continue;
      let dup = false;
      for (let k = 0; k < i; k++) if (pick[k].meal.id === c.meal.id) { dup = true; break; }
      if (dup) continue;
      pick[i] = c;
      rec(i + 1, cost + c.e.cost);
    }
  };
  rec(0, 0);
  return best;
}

function cheapestPossible(profile, ctx) {
  let total = 0;
  for (const slot of SLOTS) {
    const costs = mealsFor(slot, profile.diet).map((m) => evalMeal(m, 0.75, ctx).cost);
    total += Math.min(...costs);
  }
  return total;
}

function pickToDay(chosen) {
  const slots = {};
  SLOTS.forEach((slot, i) => { slots[slot] = { id: chosen[i].meal.id, scale: chosen[i].scale }; });
  return { slots };
}

// Turn a lightweight {slots:{slot:{id,scale}}} pick into a full day with numbers.
function describeDay(dayPick, profile, targets = computeTargets(profile)) {
  const ctx = makeCtx(profile);
  const slots = {};
  const totals = { kcal: 0, protein: 0, carbs: 0, fat: 0, cost: 0 };
  for (const slot of SLOTS) {
    const sel = dayPick.slots[slot];
    const meal = MEAL_BY_ID[sel && sel.id];
    if (!meal) throw new InputError(`Unknown meal for ${slot}.`);
    const scale = SCALES.includes(sel.scale) ? sel.scale : 1;
    const e = evalMeal(meal, scale, ctx);
    slots[slot] = {
      id: meal.id, name: meal.name, scale, diet: meal.diet, prep: meal.prep, gear: meal.gear,
      steps: meal.steps, ingredients: e.lines,
      kcal: e.kcal, protein: e.protein, carbs: e.carbs, fat: e.fat, cost: e.cost,
    };
    totals.kcal += e.kcal; totals.protein += e.protein; totals.carbs += e.carbs;
    totals.fat += e.fat; totals.cost += e.cost;
  }
  totals.protein = round1(totals.protein);
  totals.carbs = round1(totals.carbs);
  totals.fat = round1(totals.fat);

  const warnings = [];
  if (totals.protein < targets.rdaProtein) {
    warnings.push(`Protein (${totals.protein} g) is below the basic RDA of ${targets.rdaProtein} g. Try a slightly higher budget.`);
  } else if (totals.protein < targets.protein * 0.9) {
    warnings.push(`Protein is ${round1(targets.protein - totals.protein)} g short of your ${profile.goal.replace('_', ' ')} target at this budget.`);
  }
  if (totals.kcal < targets.kcal * 0.85) {
    warnings.push(`Calories land ${targets.kcal - totals.kcal} kcal under target. A bigger budget would close the gap.`);
  }
  return {
    pick: dayPick, slots, totals, targets,
    budget: profile.budget, saved: profile.budget - totals.cost, warnings,
  };
}

function generateDay(profile, history = { usage: {}, prev: null }, seed = profile.seed) {
  const targets = computeTargets(profile);
  const ctx = makeCtx(profile);
  const rng = mulberry32(seed);
  const cands = buildCandidates(profile, targets, ctx, history, rng);

  const floor = cheapestPossible(profile, ctx);
  if (floor > profile.budget) {
    throw new InputError(
      `₹${profile.budget} is too low for 4 balanced meals here. The cheapest full day costs about ₹${floor}.`,
    );
  }
  let best = searchDay(cands, targets, profile.budget, history, true);
  let relaxed = false;
  if (!best) { best = searchDay(cands, targets, profile.budget, history, false); relaxed = true; }
  if (!best) throw new InputError('Could not build a plan inside that budget.');

  const day = describeDay(pickToDay(best), profile, targets);
  if (relaxed) day.warnings.push('Budget is so tight that some meals share a protein or carb source.');
  return day;
}

function generatePlan(rawProfile) {
  const profile = normalizeProfile(rawProfile);
  const targets = computeTargets(profile);
  const usage = {};
  let prev = null;
  const days = [];
  for (let d = 0; d < profile.days; d++) {
    const day = generateDay(profile, { usage, prev }, profile.seed * 31 + d * 7 + 1);
    days.push(day);
    prev = {};
    for (const slot of SLOTS) {
      prev[slot] = day.slots[slot].id;
      usage[day.slots[slot].id] = (usage[day.slots[slot].id] || 0) + 1;
    }
  }
  return { profile, targets, days };
}

// --------------------------------------------------------------- swaps

function swapMeal(rawProfile, dayPick, slot, exclude = []) {
  const profile = normalizeProfile(rawProfile);
  if (!SLOTS.includes(slot)) throw new InputError('Unknown meal slot.');
  const ctx = makeCtx(profile);
  const targets = computeTargets(profile);
  const current = describeDay(dayPick, profile, targets);
  const cur = current.slots[slot];

  const otherCost = current.totals.cost - cur.cost;
  const remaining = profile.budget - otherCost;
  const taken = new Set(SLOTS.filter((s) => s !== slot).map((s) => current.slots[s].id));
  const idx = SLOTS.indexOf(slot);
  const neighbours = [SLOTS[idx - 1], SLOTS[idx + 1]]
    .filter(Boolean).map((s) => MEAL_BY_ID[current.slots[s].id]);

  const build = (strict) => {
    const out = [];
    for (const meal of mealsFor(slot, profile.diet)) {
      if (meal.id === cur.id || taken.has(meal.id) || exclude.includes(meal.id)) continue;
      if (strict && neighbours.some((n) => clash(n, meal))) continue;
      // Choose the portion size that best matches the dish being replaced.
      let bestOpt = null;
      for (const scale of SCALES) {
        const e = evalMeal(meal, scale, ctx);
        if (e.cost > remaining) continue;
        const diff = Math.abs(e.kcal - cur.kcal) / cur.kcal;
        if (!bestOpt || diff < bestOpt.diff) bestOpt = { scale, e, diff };
      }
      if (!bestOpt) continue;
      const proteinDiff = Math.abs(bestOpt.e.protein - cur.protein) / Math.max(cur.protein, 8);
      const costDiff = Math.abs(bestOpt.e.cost - cur.cost) / Math.max(cur.cost, 5);
      out.push({ meal, scale: bestOpt.scale, e: bestOpt.e, sim: bestOpt.diff + proteinDiff + 0.3 * costDiff });
    }
    return out.sort((a, b) => a.sim - b.sim);
  };

  let options = build(true);
  if (!options.length) options = build(false);
  if (!options.length) {
    throw new InputError('No other dish fits this slot within your budget. Try clearing earlier swaps.');
  }
  const chosen = options[0];
  const next = { slots: { ...dayPick.slots, [slot]: { id: chosen.meal.id, scale: chosen.scale } } };
  return {
    day: describeDay(next, profile, targets),
    replaced: cur.name,
    alternatives: options.slice(0, 5).map((o) => ({ id: o.meal.id, name: o.meal.name, cost: o.e.cost })),
  };
}

// --------------------------------------------------------------- grocery

function buildGrocery(dayPicks, rawProfile) {
  const profile = normalizeProfile(rawProfile);
  const need = new Map();
  for (const dp of dayPicks) {
    for (const slot of SLOTS) {
      const sel = dp.slots[slot];
      const meal = MEAL_BY_ID[sel.id];
      if (!meal) throw new InputError('Unknown meal in plan.');
      const scale = SCALES.includes(sel.scale) ? sel.scale : 1;
      for (const [id, base] of meal.ingredients) {
        const qty = scaleQty(INGREDIENTS[id], base, scale);
        need.set(id, (need.get(id) || 0) + qty);
      }
    }
  }
  const pantry = new Set(profile.pantry);
  const loose = dayPicks.length < 4; // short plans: assume loose buying, not full packs
  const byCategory = {};
  let buyTotal = 0, usedTotal = 0;
  for (const [id, qty] of need) {
    const ing = INGREDIENTS[id];
    const have = pantry.has(id);
    const step = loose ? (ing.unit === 'pc' ? 1 : 25) : ing.pack;
    const packs = Math.ceil(qty / step);
    const buyQty = packs * step;
    const bulk = !loose && ing.pack >= 500 ? 0.95 : 1; // small discount for big packs
    const buyCost = have ? 0 : Math.round((buyQty / ing.per) * ing.price * profile.priceMult * bulk);
    const usedCost = have ? 0 : Math.round((qty / ing.per) * ing.price * profile.priceMult);
    buyTotal += buyCost;
    usedTotal += usedCost;
    (byCategory[ing.category] ||= []).push({
      id, name: ing.name, unit: ing.unit, qty, packs, buyQty, buyCost, usedCost, inPantry: have,
    });
  }
  const categories = Object.entries(byCategory).map(([category, items]) => ({
    category,
    items: items.sort((a, b) => a.name.localeCompare(b.name)),
    subtotal: items.reduce((s, i) => s + i.buyCost, 0),
  })).sort((a, b) => a.category.localeCompare(b.category));

  return { categories, buyTotal, usedTotal, days: dayPicks.length };
}

// ------------------------------------------------------------- mess mode

function supplementOptions(profile, ctx) {
  const defs = [
    ['2 boiled eggs',        [['egg', 2]]],
    ['50 g roasted chana',   [['roast_chana', 50]]],
    ['30 g soya chunks (in a quick sabzi)', [['soya', 30], ['onion', 20], ['spice', 2]]],
    ['40 g peanuts',         [['peanut', 40]]],
    ['2 bananas',            [['banana', 2]]],
    ['250 ml milk',          [['milk', 250]]],
    ['200 g curd',           [['curd', 200]]],
    ['50 g sattu drink',     [['sattu', 50], ['lemon', 1]]],
    ['30 g peanut butter',   [['pbutter', 30]]],
  ];
  return defs.map(([label, ings]) => {
    const meal = { ingredients: ings };
    const e = evalMeal(meal, 1, ctx);
    const diet = ings.reduce((r, [id]) => Math.max(r, DIET_RANK[INGREDIENTS[id].diet]), 0);
    return { label, e, diet };
  }).filter((o) => o.diet <= DIETS[profile.diet]);
}

function messPlan(rawProfile) {
  const profile = normalizeProfile(rawProfile);
  const targets = computeTargets(profile);
  const ctx = makeCtx(profile);
  const share = { breakfast: 0.28, lunch: 0.38, dinner: 0.34 };

  const picks = {};
  let kcal = 0, protein = 0, carbs = 0, fat = 0;
  for (const slot of Object.keys(share)) {
    const options = MESS_MENU[slot].filter((d) => dietAllowed(d.diet, profile.diet));
    const tk = targets.kcal * share[slot];
    const tp = targets.protein * share[slot];
    let best = null;
    for (const d of options) {
      const s = Math.abs(d.kcal - tk) / tk + 2.5 * Math.max(0, tp - d.protein) / tp;
      if (!best || s < best.s) best = { d, s };
    }
    picks[slot] = best.d;
    kcal += best.d.kcal; protein += best.d.protein; carbs += best.d.carbs; fat += best.d.fat;
  }

  // Fill the remaining gap with the cheapest protein from outside.
  const supplements = [];
  let spend = 0;
  const options = supplementOptions(profile, ctx);
  const used = {};
  for (let guard = 0; guard < 5; guard++) {
    const gapP = targets.protein - protein;
    const gapK = targets.kcal - kcal;
    if (gapP <= 3 && gapK <= 150) break;
    let best = null;
    for (const o of options) {
      if ((used[o.label] || 0) >= 2 || spend + o.e.cost > profile.budget) continue;
      const value = Math.min(o.e.protein, Math.max(gapP, 0)) + 0.03 * Math.min(o.e.kcal, Math.max(gapK, 0));
      const perRupee = value / Math.max(o.e.cost, 1);
      if (value > 0 && (!best || perRupee > best.perRupee)) best = { o, perRupee };
    }
    if (!best) break;
    used[best.o.label] = (used[best.o.label] || 0) + 1;
    supplements.push({ label: best.o.label, cost: best.o.e.cost, kcal: best.o.e.kcal, protein: best.o.e.protein });
    spend += best.o.e.cost;
    kcal += best.o.e.kcal; protein += best.o.e.protein; carbs += best.o.e.carbs; fat += best.o.e.fat;
  }

  const grouped = [];
  for (const s of supplements) {
    const hit = grouped.find((g) => g.label === s.label);
    if (hit) { hit.count += 1; hit.cost += s.cost; hit.kcal += s.kcal; hit.protein = round1(hit.protein + s.protein); }
    else grouped.push({ ...s, count: 1 });
  }
  return {
    targets,
    mess: picks,
    supplements: grouped,
    totals: { kcal: Math.round(kcal), protein: round1(protein), carbs: round1(carbs), fat: round1(fat), cost: spend },
    budget: profile.budget,
  };
}

// --------------------------------------------------------- recipe search

function searchRecipes({ diet, slot, q } = {}) {
  const needle = (q || '').trim().toLowerCase();
  const ctx = makeCtx(normalizeProfile({}));
  return MEALS
    .filter((m) => !diet || (diet in DIETS && dietAllowed(m.diet, diet)))
    .filter((m) => !slot || m.slots.includes(SLOT_LETTER[slot]))
    .filter((m) => !needle || m.name.toLowerCase().includes(needle)
      || m.ingredients.some(([id]) => INGREDIENTS[id].name.toLowerCase().includes(needle)))
    .map((m) => {
      const e = evalMeal(m, 1, ctx);
      return {
        id: m.id, name: m.name, diet: m.diet, slots: m.slots, prep: m.prep, gear: m.gear,
        kcal: e.kcal, protein: e.protein, carbs: e.carbs, fat: e.fat, cost: e.cost,
      };
    });
}

// Cost + macros for a custom recipe (used by the community board).
function priceRecipe(items, priceMult = 1) {
  const ctx = { mult: priceMult, pantry: new Set(), diet: 'nonveg' };
  const e = evalMeal({ ingredients: items.map((i) => [i.id, i.qty]) }, 1, ctx);
  const diet = items.reduce((r, i) => Math.max(r, DIET_RANK[INGREDIENTS[i.id].diet]), 0);
  return { cost: e.cost, kcal: e.kcal, protein: e.protein, diet: ['vegan', 'veg', 'nonveg'][diet] };
}

module.exports = {
  SLOTS, SCALES, GOALS, DIETS, MEALS, INGREDIENTS, MEAL_BY_ID,
  InputError, normalizeProfile, computeTargets,
  generatePlan, generateDay, describeDay, swapMeal,
  buildGrocery, messPlan, searchRecipes, priceRecipe,
};
