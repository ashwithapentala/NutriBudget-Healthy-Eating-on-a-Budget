'use strict';

/*
 * 50 hostel-friendly Indian meals.
 *
 * Each meal is just a list of ingredients with quantities. Cost, calories and
 * macros are NOT typed in by hand - the engine derives them from the
 * ingredient table, so a price change in one place flows everywhere
 * (meal cards, grocery list, the optimizer).
 *
 *   slots : b = breakfast, l = lunch, s = snack, d = dinner
 *   pk    : main protein source, ck: main carb source. The optimizer uses them
 *           so the same protein / carb does not show up in back-to-back meals.
 *   gear  : what a hostel room needs to make it.
 */

const { INGREDIENTS } = require('./ingredients');

const m = (id, name, slots, pk, ck, prep, gear, ingredients, steps) => ({
  id, name, slots: slots.split(''), pk, ck, prep, gear, ingredients, steps,
});

const RAW_MEALS = [
  // ---------------------------------------------------------------- breakfast
  m('egg_bhurji_roti', 'Egg Bhurji & Roti', 'bd', 'egg', 'roti', 20, 'induction / stove',
    [['egg', 2], ['atta', 60], ['onion', 30], ['tomato', 30], ['oil', 5], ['spice', 3]],
    ['Knead atta with water and roll 2 rotis; cook on a hot tawa.',
     'Fry chopped onion and tomato in oil with the masala for 3 minutes.',
     'Crack in the eggs, stir until just set, and eat with the rotis.']),

  m('bread_omelette', 'Masala Bread Omelette', 'b', 'egg', 'bread', 10, 'induction / stove',
    [['egg', 2], ['bread', 3], ['onion', 20], ['oil', 5], ['spice', 2]],
    ['Beat eggs with chopped onion and masala.',
     'Pour into a lightly oiled pan, cook until the underside sets, flip once.',
     'Toast the bread in the same pan and serve alongside.']),

  m('peanut_butter_toast', 'Peanut Butter Toast & Banana', 'bs', 'peanut', 'bread', 5, 'none',
    [['bread', 3], ['pbutter', 25], ['banana', 1]],
    ['Toast the bread on a tawa or sandwich maker.',
     'Spread peanut butter, slice the banana over it.']),

  m('oats_banana_milk', 'Banana Milk Oats', 'b', 'milk', 'oats', 8, 'kettle',
    [['oats', 50], ['milk', 200], ['banana', 1], ['sugar', 5]],
    ['Boil the milk in a kettle or pan and pour over the oats.',
     'Let it sit 3 minutes, add sliced banana and a little sugar.']),

  m('oats_pb_banana', 'Peanut Butter Banana Oats (vegan)', 'bs', 'peanut', 'oats', 8, 'kettle',
    [['oats', 50], ['pbutter', 15], ['banana', 1]],
    ['Pour hot water from the kettle over the oats and cover for 4 minutes.',
     'Stir in the peanut butter and top with sliced banana.']),

  m('poha_peanuts', 'Peanut Poha', 'bs', 'peanut', 'poha', 15, 'induction / stove',
    [['poha', 70], ['peanut', 15], ['onion', 30], ['oil', 6], ['spice', 2], ['lemon', 1]],
    ['Rinse the poha in a sieve and let it soften.',
     'Fry peanuts, then onion, in oil. Add masala.',
     'Fold in the poha, heat for 2 minutes, finish with lemon juice.']),

  m('veg_upma', 'Vegetable Upma', 'b', 'none', 'suji', 15, 'induction / stove',
    [['suji', 60], ['mixveg', 50], ['onion', 20], ['peanut', 10], ['oil', 8], ['spice', 2]],
    ['Dry roast the suji for 3 minutes and set aside.',
     'Fry onion, peanuts and chopped veg in oil.',
     'Add 2 cups hot water and masala, stream in the suji while stirring, cover 3 minutes.']),

  m('besan_chilla', 'Besan Chilla (vegan)', 'bd', 'besan', 'none', 15, 'induction / stove',
    [['besan', 70], ['onion', 25], ['tomato', 25], ['oil', 8], ['spice', 3]],
    ['Whisk besan with water, masala, chopped onion and tomato into a pourable batter.',
     'Spread a ladle on an oiled tawa, cook both sides until golden.']),

  m('sprouts_chaat', 'Moong Sprouts Chaat', 'bs', 'moong', 'none', 10, 'none',
    [['moong', 60], ['onion', 20], ['tomato', 20], ['lemon', 1], ['spice', 2]],
    ['Soak the moong overnight, drain, and leave in a cloth for 8-10 hours to sprout.',
     'Steam or microwave 3 minutes if you like it softer.',
     'Toss with onion, tomato, lemon and masala.']),

  m('dalia_milk_porridge', 'Sweet Dalia Porridge', 'b', 'milk', 'dalia', 20, 'induction / stove',
    [['dalia', 60], ['milk', 200], ['sugar', 8]],
    ['Roast dalia 2 minutes in a dry pan.',
     'Add milk and a splash of water, simmer 12-15 minutes stirring now and then.',
     'Sweeten and serve warm.']),

  m('paneer_bhurji_roti', 'Paneer Bhurji & Roti', 'bd', 'paneer', 'roti', 20, 'induction / stove',
    [['paneer', 80], ['atta', 60], ['onion', 30], ['tomato', 30], ['oil', 6], ['spice', 3]],
    ['Crumble the paneer by hand.',
     'Fry onion and tomato with masala, add paneer, stir for 3 minutes.',
     'Serve with freshly made rotis.']),

  m('aloo_paratha_curd', 'Aloo Paratha & Curd', 'b', 'curd', 'roti', 30, 'induction / stove',
    [['atta', 80], ['potato', 100], ['curd', 100], ['oil', 10], ['spice', 3]],
    ['Boil and mash the potato, mix in masala.',
     'Stuff into atta dough balls, roll flat, cook with a little oil until spotted brown.',
     'Eat with cold curd.']),

  m('sattu_drink_banana', 'Sattu Nimbu Drink & Banana (vegan)', 'bs', 'sattu', 'none', 5, 'none',
    [['sattu', 50], ['lemon', 1], ['sugar', 5], ['banana', 1], ['spice', 1]],
    ['Stir sattu into a glass of cold water until smooth.',
     'Add lemon juice, a pinch of masala and a little sugar. Eat the banana on the side.']),

  m('moong_dal_chilla', 'Moong Dal Chilla & Curd', 'b', 'dal', 'none', 15, 'induction / stove',
    [['moong_dal', 60], ['curd', 60], ['onion', 20], ['oil', 8], ['spice', 3]],
    ['Soak the dal for 2 hours, grind to a batter with masala.',
     'Spread thin on an oiled tawa, add onion, cook both sides.',
     'Serve with curd.']),

  m('boiled_eggs_banana_toast', 'Boiled Eggs, Toast & Banana', 'bs', 'egg', 'bread', 12, 'kettle / stove',
    [['egg', 3], ['bread', 2], ['banana', 1], ['spice', 1]],
    ['Boil eggs 9-10 minutes, cool in cold water, peel.',
     'Sprinkle masala, eat with toast and the banana.']),

  m('paneer_bhurji_sprouts', 'Paneer Bhurji & Sprouts', 'bl', 'paneer', 'none', 20, 'induction / stove',
    [['paneer', 60], ['moong', 35], ['onion', 30], ['tomato', 30], ['oil', 6], ['spice', 3]],
    ['Use sprouted moong (soak overnight, rest in cloth).',
     'Fry onion and tomato with masala, add crumbled paneer and sprouts.',
     'Cook 4 minutes until the sprouts are tender.']),

  m('egg_masala_sandwich', 'Egg Masala Sandwich', 'b', 'egg', 'bread', 12, 'induction / stove',
    [['bread', 4], ['egg', 2], ['tomato', 20], ['onion', 15], ['oil', 4], ['spice', 2]],
    ['Scramble eggs with chopped onion, tomato and masala.',
     'Pile between toasted bread slices and press on a hot tawa.']),

  // ------------------------------------------------------------------- snacks
  m('roasted_chana_tea', 'Roasted Chana & Chai', 's', 'chana', 'none', 5, 'kettle',
    [['roast_chana', 40], ['milk', 100], ['tea', 2], ['sugar', 5]],
    ['Brew tea with milk and sugar.', 'Eat the roasted chana on the side.']),

  m('roasted_chana_chaat', 'Roasted Chana Chaat (vegan)', 's', 'chana', 'none', 5, 'none',
    [['roast_chana', 50], ['onion', 20], ['tomato', 20], ['lemon', 1], ['spice', 2]],
    ['Mix everything in a bowl and let it sit a minute so the chana softens a little.']),

  m('peanut_banana', 'Peanuts & Banana (vegan)', 's', 'peanut', 'none', 2, 'none',
    [['peanut', 30], ['banana', 1]],
    ['Nothing to cook. Handful of peanuts plus a banana.']),

  m('curd_banana_bowl', 'Curd & Banana Bowl', 's', 'curd', 'none', 3, 'none',
    [['curd', 150], ['banana', 1], ['sugar', 5]],
    ['Slice the banana into the curd, add a little sugar and stir.']),

  m('soya_chaat', 'Soya Chunk Chaat (vegan)', 's', 'soya', 'none', 12, 'kettle / stove',
    [['soya', 35], ['onion', 20], ['tomato', 20], ['lemon', 1], ['spice', 2]],
    ['Soak soya chunks in hot water for 10 minutes, squeeze out the water.',
     'Toss with onion, tomato, lemon and masala. Pan-toast for 2 minutes if you want crunch.']),

  m('sweet_lassi', 'Sweet Lassi', 's', 'curd', 'none', 3, 'none',
    [['curd', 200], ['sugar', 10]],
    ['Whisk curd, sugar and a splash of cold water until smooth.']),

  m('boiled_chana_chaat', 'Kala Chana Chaat (vegan)', 's', 'chana', 'none', 25, 'pressure cooker',
    [['chole', 40], ['onion', 20], ['tomato', 20], ['lemon', 1], ['spice', 2]],
    ['Soak chana overnight, pressure cook 4 whistles with salt.',
     'Toss with onion, tomato, lemon and masala. Cook a big batch and keep it 2 days in the fridge.']),

  m('boiled_eggs_masala', 'Masala Boiled Eggs', 's', 'egg', 'none', 12, 'kettle / stove',
    [['egg', 2], ['spice', 1]],
    ['Boil 9-10 minutes, peel, halve, and sprinkle with masala.']),

  m('milk_banana_shake', 'Banana Peanut Shake', 's', 'milk', 'none', 5, 'none',
    [['milk', 250], ['banana', 1], ['peanut', 15], ['sugar', 5]],
    ['Blend or whisk everything hard in a bottle shaker until mostly smooth.']),

  m('peanut_chaat', 'Peanut Chaat (vegan)', 's', 'peanut', 'none', 5, 'none',
    [['peanut', 40], ['onion', 20], ['tomato', 20], ['lemon', 1], ['spice', 2]],
    ['Toss roasted peanuts with onion, tomato, lemon and masala.']),

  // ------------------------------------------------------------ lunch / dinner
  m('dal_tadka_rice', 'Dal Tadka & Rice', 'ld', 'dal', 'rice', 30, 'pressure cooker',
    [['toor', 50], ['rice', 80], ['onion', 30], ['tomato', 30], ['oil', 8], ['spice', 4]],
    ['Pressure cook washed toor dal with turmeric and salt, 4 whistles. Cook rice alongside.',
     'Heat oil, fry onion and tomato with masala, pour the tadka over the mashed dal.']),

  m('soya_curry_rice', 'Soya Chunks Curry & Rice', 'ld', 'soya', 'rice', 30, 'induction / stove',
    [['soya', 40], ['rice', 80], ['onion', 40], ['tomato', 40], ['oil', 8], ['spice', 4]],
    ['Soak soya in hot water 10 minutes, squeeze dry.',
     'Fry onion, add tomato and masala until it breaks down into a gravy.',
     'Add soya and half a cup of water, simmer 8 minutes. Serve over rice.']),

  m('rajma_chawal', 'Rajma Chawal (vegan)', 'ld', 'rajma', 'rice', 45, 'pressure cooker',
    [['rajma', 50], ['rice', 80], ['onion', 30], ['tomato', 40], ['oil', 8], ['spice', 4]],
    ['Soak rajma overnight, pressure cook 6-7 whistles.',
     'Fry onion and tomato with masala, add the rajma with its water, simmer 10 minutes.',
     'Eat with rice.']),

  m('chole_roti', 'Chole & Roti (vegan)', 'ld', 'chana', 'roti', 45, 'pressure cooker',
    [['chole', 60], ['atta', 70], ['onion', 30], ['tomato', 40], ['oil', 8], ['spice', 4]],
    ['Soak chole overnight, pressure cook until soft.',
     'Make a quick onion-tomato masala, add chole and simmer 10 minutes.',
     'Roll and cook 2-3 rotis.']),

  m('dal_khichdi_curd', 'Dal Khichdi & Curd', 'ld', 'dal', 'rice', 30, 'pressure cooker',
    [['moong_dal', 40], ['rice', 60], ['mixveg', 50], ['oil', 6], ['spice', 3], ['curd', 100]],
    ['Wash dal and rice together and put in the cooker with chopped veg, turmeric, salt, 4 cups water.',
     '3-4 whistles. Mash lightly, add a tadka of oil and masala.',
     'Serve with a bowl of curd.']),

  m('egg_curry_rice', 'Egg Curry & Rice', 'ld', 'egg', 'rice', 30, 'induction / stove',
    [['egg', 3], ['rice', 80], ['onion', 40], ['tomato', 40], ['oil', 10], ['spice', 4]],
    ['Boil and peel the eggs, make a few slits in them.',
     'Cook onion and tomato with masala into a thick gravy, slide the eggs in for 5 minutes.',
     'Serve with rice.']),

  m('chicken_curry_rice', 'Chicken Curry & Rice', 'ld', 'chicken', 'rice', 40, 'pressure cooker',
    [['chicken', 120], ['rice', 80], ['onion', 40], ['tomato', 40], ['oil', 10], ['spice', 5]],
    ['Fry onion until golden, add tomato and masala.',
     'Add chicken and a little water, pressure cook 3 whistles.',
     'Serve with rice.']),

  m('chicken_stirfry_roti', 'Chicken Veg Stir-fry & Roti', 'ld', 'chicken', 'roti', 35, 'induction / stove',
    [['chicken', 100], ['mixveg', 80], ['atta', 70], ['oil', 8], ['spice', 4]],
    ['Fry chicken pieces in oil with masala for 8 minutes.',
     'Add chopped veg, cook until just tender.',
     'Make rotis on the side.']),

  m('paneer_curry_rice', 'Paneer Curry & Rice', 'ld', 'paneer', 'rice', 30, 'induction / stove',
    [['paneer', 70], ['rice', 80], ['onion', 40], ['tomato', 50], ['oil', 8], ['spice', 4]],
    ['Cook onion and tomato with masala into a smooth gravy (mash with the back of a spoon).',
     'Add cubed paneer and simmer 4 minutes. Serve with rice.']),

  m('palak_dal_roti', 'Palak Dal & Roti (vegan)', 'ld', 'dal', 'roti', 35, 'pressure cooker',
    [['masoor', 50], ['spinach', 100], ['atta', 80], ['onion', 20], ['oil', 8], ['spice', 3]],
    ['Pressure cook masoor dal until mushy.',
     'Wilt chopped spinach in hot oil with onion and masala, stir into the dal.',
     'Eat with rotis.']),

  m('mixveg_roti_curd', 'Mixed Veg Sabzi, Roti & Curd', 'ld', 'curd', 'roti', 30, 'induction / stove',
    [['mixveg', 150], ['atta', 90], ['curd', 100], ['oil', 8], ['spice', 4]],
    ['Cook the chopped veg with oil and masala, covered, until soft.',
     'Roll and cook the rotis, and serve with a bowl of curd.']),

  m('soya_pulao', 'Soya Veg Pulao (vegan)', 'ld', 'soya', 'rice', 30, 'pressure cooker',
    [['soya', 40], ['rice', 80], ['mixveg', 60], ['onion', 30], ['oil', 8], ['spice', 4]],
    ['Soak and squeeze the soya.',
     'Fry onion, add veg, soya and masala for 3 minutes.',
     'Add rice and 1.5x water, one whistle in the cooker.']),

  m('egg_fried_rice', 'Egg Fried Rice', 'ld', 'egg', 'rice', 20, 'induction / stove',
    [['egg', 3], ['rice', 90], ['mixveg', 60], ['onion', 20], ['oil', 8], ['spice', 3]],
    ['Use leftover cold rice if you have it.',
     'Scramble eggs in oil, push aside, stir-fry veg and onion.',
     'Add rice and masala, toss on high heat for 3 minutes.']),

  m('chana_dal_roti', 'Chana Dal & Roti (vegan)', 'ld', 'dal', 'roti', 35, 'pressure cooker',
    [['chana_dal', 50], ['atta', 80], ['onion', 30], ['tomato', 30], ['oil', 8], ['spice', 4]],
    ['Soak chana dal 30 minutes, pressure cook 4 whistles.',
     'Temper with onion, tomato and masala.',
     'Serve with rotis.']),

  m('curd_rice_peanut', 'Curd Rice with Peanuts', 'ld', 'curd', 'rice', 20, 'induction / stove',
    [['rice', 90], ['curd', 200], ['peanut', 15], ['oil', 4], ['spice', 2]],
    ['Cook rice soft and let it cool a little.',
     'Mix with curd and salt. Temper peanuts in hot oil and pour on top.']),

  m('aloo_soya_roti', 'Aloo Soya Sabzi & Roti (vegan)', 'ld', 'soya', 'roti', 30, 'induction / stove',
    [['soya', 30], ['potato', 120], ['atta', 70], ['oil', 8], ['spice', 4]],
    ['Parboil cubed potato, soak the soya.',
     'Fry both in oil with masala for 8 minutes.',
     'Serve with rotis.']),

  m('masoor_dal_rice', 'Masoor Dal & Rice (vegan)', 'ld', 'dal', 'rice', 25, 'pressure cooker',
    [['masoor', 50], ['rice', 80], ['onion', 30], ['oil', 6], ['spice', 4]],
    ['Masoor needs no soaking. Pressure cook with rice in separate containers, 3 whistles.',
     'Finish the dal with a quick onion tadka.']),

  m('sprouts_curry_roti', 'Sprouts Curry & Roti (vegan)', 'ld', 'moong', 'roti', 30, 'induction / stove',
    [['moong', 60], ['atta', 70], ['onion', 30], ['tomato', 40], ['oil', 8], ['spice', 4]],
    ['Sprout the moong (overnight soak plus a day in a cloth).',
     'Make an onion-tomato masala, add the sprouts and a splash of water, cover 8 minutes.',
     'Serve with rotis.']),

  m('egg_roll_wrap', 'Egg Roti Roll', 'ld', 'egg', 'roti', 20, 'induction / stove',
    [['egg', 3], ['atta', 70], ['onion', 30], ['oil', 8], ['spice', 3]],
    ['Make rotis. Beat eggs with onion and masala.',
     'Pour egg onto a roti on the tawa, flip once, roll it up.']),

  m('dalia_veg_khichdi', 'Dalia Veg Khichdi (vegan)', 'ld', 'dal', 'dalia', 30, 'pressure cooker',
    [['dalia', 70], ['moong_dal', 30], ['mixveg', 60], ['oil', 6], ['spice', 3]],
    ['Put dalia, dal and chopped veg in the cooker with 3 cups water and salt.',
     '3 whistles. Finish with a drizzle of oil and masala.']),

  m('soya_keema_roti', 'Soya Keema & Roti (vegan)', 'ld', 'soya', 'roti', 30, 'induction / stove',
    [['soya', 40], ['atta', 70], ['onion', 40], ['tomato', 40], ['oil', 8], ['spice', 5]],
    ['Soak soya, squeeze dry, and pulse or crumble it fine.',
     'Cook onion, tomato and masala, add the soya and a splash of water, simmer 8 minutes.',
     'Serve with rotis.']),

  m('chicken_pulao', 'Chicken Pulao', 'ld', 'chicken', 'rice', 40, 'pressure cooker',
    [['chicken', 100], ['rice', 90], ['onion', 40], ['oil', 10], ['spice', 5]],
    ['Brown the onion, add chicken and masala for 5 minutes.',
     'Add washed rice and 1.5x water, one whistle in the cooker.']),

  m('toor_dal_roti_salad', 'Dal, Roti & Onion Salad (vegan)', 'ld', 'dal', 'roti', 30, 'pressure cooker',
    [['toor', 50], ['atta', 80], ['onion', 30], ['tomato', 30], ['oil', 6], ['spice', 4]],
    ['Pressure cook the dal, temper with a little oil and masala.',
     'Roll rotis, slice raw onion and tomato as a side salad.']),
];

// Work out each meal's diet from its ingredients (strictest ingredient wins).
const DIET_RANK = { vegan: 0, veg: 1, nonveg: 2 };
const RANK_TO_DIET = ['vegan', 'veg', 'nonveg'];

for (const meal of RAW_MEALS) {
  let rank = 0;
  for (const [id] of meal.ingredients) {
    const ing = INGREDIENTS[id];
    if (!ing) throw new Error(`Meal ${meal.id} uses unknown ingredient ${id}`);
    rank = Math.max(rank, DIET_RANK[ing.diet]);
  }
  meal.diet = RANK_TO_DIET[rank];
}

const MEALS = RAW_MEALS;

module.exports = { MEALS, DIET_RANK };
