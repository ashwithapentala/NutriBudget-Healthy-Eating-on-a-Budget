'use strict';

/*
 * Ingredient price + nutrition table.
 *
 * Prices are rough 2026 Indian retail averages in rupees (a median of what
 * local kirana / supermarket shelves show). They are ESTIMATES, which is why
 * the UI has a price-adjust slider. Nutrition is per `per` units
 * (100 g, 100 ml, or 1 piece) and follows the usual IFCT / USDA ballparks.
 *
 * diet: 'vegan' < 'veg' (dairy) < 'nonveg' (egg, meat).
 *   Eggs are treated as non-veg on purpose so "Vegetarian" means the
 *   Indian meaning of the word.
 * fixed: quantity does not scale with portion size (a lemon is a lemon).
 * pack: smallest sensible shop pack, used by the grocery list.
 */

const COLUMNS = [
  'id', 'name', 'category', 'unit', 'per', 'price',
  'kcal', 'protein', 'carbs', 'fat', 'diet', 'pack',
];

const ROWS = [
  // Grains & flours
  ['rice',       'Rice',               'Grains & Flours',   'g',  100, 6.5,  350, 7,    78,  0.6, 'vegan', 1000],
  ['atta',       'Wheat atta',         'Grains & Flours',   'g',  100, 5,    340, 12,   71,  1.7, 'vegan', 1000],
  ['oats',       'Rolled oats',        'Grains & Flours',   'g',  100, 18,   389, 17,   66,  7,   'vegan', 500],
  ['poha',       'Poha',               'Grains & Flours',   'g',  100, 8,    360, 7,    77,  1.5, 'vegan', 500],
  ['suji',       'Suji (rava)',        'Grains & Flours',   'g',  100, 5.5,  350, 12,   73,  1,   'vegan', 500],
  ['dalia',      'Dalia',              'Grains & Flours',   'g',  100, 6,    342, 12,   69,  1.9, 'vegan', 500],
  ['bread',      'Bread slice',        'Grains & Flours',   'pc', 1,   3.5,  75,  2.5,  14,  1,   'vegan', 12],

  // Pulses, soya, flours
  ['toor',       'Toor dal',           'Pulses & Soya',     'g',  100, 14,   343, 22,   63,  1.5, 'vegan', 500],
  ['moong_dal',  'Moong dal',          'Pulses & Soya',     'g',  100, 12,   347, 24,   60,  1.2, 'vegan', 500],
  ['masoor',     'Masoor dal',         'Pulses & Soya',     'g',  100, 9.5,  343, 25,   60,  1.1, 'vegan', 500],
  ['chana_dal',  'Chana dal',          'Pulses & Soya',     'g',  100, 9,    360, 20,   60,  5,   'vegan', 500],
  ['rajma',      'Rajma',              'Pulses & Soya',     'g',  100, 13,   333, 24,   60,  0.8, 'vegan', 500],
  ['chole',      'Kabuli chana',       'Pulses & Soya',     'g',  100, 12,   364, 19,   61,  6,   'vegan', 500],
  ['roast_chana','Roasted chana',      'Pulses & Soya',     'g',  100, 14,   364, 22,   58,  5,   'vegan', 250],
  ['moong',      'Whole moong',        'Pulses & Soya',     'g',  100, 11,   347, 24,   63,  1.2, 'vegan', 500],
  ['soya',       'Soya chunks',        'Pulses & Soya',     'g',  100, 14,   345, 52,   33,  0.5, 'vegan', 500],
  ['besan',      'Besan',              'Pulses & Soya',     'g',  100, 9,    387, 22,   58,  6.7, 'vegan', 500],
  ['sattu',      'Sattu',              'Pulses & Soya',     'g',  100, 10,   413, 20,   65,  7,   'vegan', 500],

  // Nuts & spreads
  ['peanut',     'Peanuts',            'Nuts & Spreads',    'g',  100, 14,   567, 26,   16,  49,  'vegan', 500],
  ['pbutter',    'Peanut butter',      'Nuts & Spreads',    'g',  100, 25,   588, 25,   20,  50,  'vegan', 500],

  // Dairy & eggs
  ['egg',        'Egg',                'Dairy & Eggs',      'pc', 1,   7,    72,  6.3,  0.4, 5,   'nonveg', 12],
  ['paneer',     'Paneer',             'Dairy & Eggs',      'g',  100, 35,   296, 18,   3.4, 22,  'veg',   200],
  ['curd',       'Curd (dahi)',        'Dairy & Eggs',      'g',  100, 8,    60,  3.5,  4.7, 3.3, 'veg',   400],
  ['milk',       'Milk',               'Dairy & Eggs',      'ml', 100, 6,    62,  3.2,  4.8, 3.5, 'veg',   500],

  // Meat
  ['chicken',    'Chicken (raw)',      'Meat',              'g',  100, 22,   120, 22,   0,   2.6, 'nonveg', 500],

  // Vegetables & fruit
  ['banana',     'Banana',             'Vegetables & Fruit','pc', 1,   5,    90,  1,    23,  0.3, 'vegan', 6],
  ['potato',     'Potato',             'Vegetables & Fruit','g',  100, 3,    77,  2,    17,  0.1, 'vegan', 1000],
  ['onion',      'Onion',              'Vegetables & Fruit','g',  100, 3.5,  40,  1.1,  9,   0.1, 'vegan', 1000],
  ['tomato',     'Tomato',             'Vegetables & Fruit','g',  100, 4,    18,  0.9,  3.9, 0.2, 'vegan', 500],
  ['mixveg',     'Seasonal veg',       'Vegetables & Fruit','g',  100, 4,    45,  2.2,  8.5, 0.4, 'vegan', 500],
  ['spinach',    'Spinach (palak)',    'Vegetables & Fruit','g',  100, 3,    23,  2.9,  3.6, 0.4, 'vegan', 250],
  ['lemon',      'Lemon',              'Vegetables & Fruit','pc', 1,   2,    10,  0.3,  3,   0.1, 'vegan', 4, true],

  // Pantry & spices
  ['oil',        'Cooking oil',        'Pantry & Spices',   'g',  100, 17,   884, 0,    0,   100, 'vegan', 500],
  ['sugar',      'Sugar',              'Pantry & Spices',   'g',  100, 4.5,  387, 0,    100, 0,   'vegan', 1000],
  ['tea',        'Tea leaves',         'Pantry & Spices',   'g',  100, 40,   0,   0,    0,   0,   'vegan', 250, true],
  ['spice',      'Masala & salt',      'Pantry & Spices',   'g',  100, 25,   280, 10,   50,  8,   'vegan', 100, true],
];

const INGREDIENTS = {};
for (const row of ROWS) {
  const ing = {};
  COLUMNS.forEach((col, i) => { ing[col] = row[i]; });
  ing.fixed = row[12] === true;
  INGREDIENTS[ing.id] = Object.freeze(ing);
}

module.exports = { INGREDIENTS };
