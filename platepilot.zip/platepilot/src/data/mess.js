'use strict';

/*
 * A typical Indian hostel mess menu (the prepaid food students already pay for).
 * Numbers are ballpark per standard serving. Edit this file to match your mess.
 * diet: 'vegan' | 'veg' | 'nonveg'
 */

const MESS_MENU = {
  breakfast: [
    { name: 'Poha',                          kcal: 250, protein: 5,  carbs: 42, fat: 7,  diet: 'vegan' },
    { name: 'Idli (4) with sambar',          kcal: 300, protein: 9,  carbs: 56, fat: 4,  diet: 'vegan' },
    { name: 'Upma',                          kcal: 260, protein: 6,  carbs: 40, fat: 8,  diet: 'vegan' },
    { name: 'Aloo paratha (2) with curd',    kcal: 480, protein: 12, carbs: 62, fat: 20, diet: 'veg' },
    { name: 'Bread, butter & tea',           kcal: 290, protein: 6,  carbs: 40, fat: 11, diet: 'veg' },
    { name: 'Boiled eggs (2) & bread',       kcal: 270, protein: 15, carbs: 26, fat: 11, diet: 'nonveg' },
  ],
  lunch: [
    { name: 'Rice, dal, sabzi & 2 roti',     kcal: 640, protein: 18, carbs: 108, fat: 12, diet: 'vegan' },
    { name: 'Rajma chawal',                  kcal: 600, protein: 18, carbs: 100, fat: 11, diet: 'vegan' },
    { name: 'Veg pulao & raita',             kcal: 480, protein: 11, carbs: 78,  fat: 12, diet: 'veg' },
    { name: 'Egg curry & rice',              kcal: 580, protein: 22, carbs: 78,  fat: 18, diet: 'nonveg' },
    { name: 'Chicken curry & rice',          kcal: 650, protein: 30, carbs: 80,  fat: 20, diet: 'nonveg' },
  ],
  dinner: [
    { name: '3 roti, dal & mixed veg',       kcal: 540, protein: 16, carbs: 88, fat: 12, diet: 'vegan' },
    { name: 'Khichdi & kadhi',               kcal: 480, protein: 13, carbs: 76, fat: 12, diet: 'veg' },
    { name: 'Paneer sabzi & 3 roti',         kcal: 600, protein: 20, carbs: 70, fat: 25, diet: 'veg' },
    { name: 'Egg bhurji & 3 roti',           kcal: 520, protein: 22, carbs: 58, fat: 20, diet: 'nonveg' },
    { name: 'Chicken & 3 roti',              kcal: 620, protein: 32, carbs: 60, fat: 22, diet: 'nonveg' },
  ],
};

module.exports = { MESS_MENU };
