'use strict';

/*
 * API handlers, kept separate from Express so they can be tested without a
 * server. Every handler takes plain data and returns plain data, or throws
 * ApiError(status, message).
 */

const crypto = require('crypto');
const engine = require('./engine');
const store = require('./store');

class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Engine validation errors are the user's fault (400); anything else is ours.
function guard(fn) {
  return (...args) => {
    try {
      return fn(...args);
    } catch (err) {
      if (err instanceof engine.InputError) throw new ApiError(400, err.message);
      throw err;
    }
  };
}

const newId = () => crypto.randomBytes(6).toString('hex');
const clean = (s, max) => String(s || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);

const handlers = {
  meta() {
    return {
      goals: Object.entries(engine.GOALS).map(([id, g]) => ({ id, label: g.label })),
      diets: [
        { id: 'vegetarian', label: 'Vegetarian' },
        { id: 'nonveg', label: 'Non-Veg' },
        { id: 'vegan', label: 'Vegan' },
      ],
      slots: engine.SLOTS,
      ingredients: Object.values(engine.INGREDIENTS).map((i) => ({
        id: i.id, name: i.name, category: i.category, unit: i.unit,
      })),
      recipeCount: engine.MEALS.length,
    };
  },

  recipes(query = {}) {
    return { recipes: engine.searchRecipes(query) };
  },

  plan(body = {}) {
    const result = engine.generatePlan(body.profile || body);
    return result;
  },

  swap(body = {}) {
    if (!body.day || !body.day.slots) throw new ApiError(400, 'Missing day to swap in.');
    const exclude = Array.isArray(body.exclude) ? body.exclude.slice(0, 60) : [];
    return engine.swapMeal(body.profile, body.day, body.slot, exclude);
  },

  grocery(body = {}) {
    if (!Array.isArray(body.days) || !body.days.length) throw new ApiError(400, 'Send the days of your plan.');
    if (body.days.length > 7) throw new ApiError(400, 'A grocery list covers at most 7 days.');
    return engine.buildGrocery(body.days, body.profile);
  },

  mess(body = {}) {
    return engine.messPlan(body.profile || body);
  },

  savePlan(body = {}) {
    const clientId = clean(body.clientId, 40);
    if (!clientId) throw new ApiError(400, 'clientId is required.');
    if (!Array.isArray(body.days) || !body.days.length) throw new ApiError(400, 'No plan to save.');
    const profile = engine.normalizeProfile(body.profile);
    const doc = {
      id: newId(), clientId, createdAt: new Date().toISOString(),
      profile, days: body.days.slice(0, 7).map((d) => ({ slots: d.slots })),
    };
    // Validate by re-describing: rejects tampered meal ids.
    doc.days.forEach((d) => engine.describeDay(d, profile));
    store.insert('mealPlans', doc, 300);
    return { id: doc.id, createdAt: doc.createdAt };
  },

  listPlans(query = {}) {
    const clientId = clean(query.clientId, 40);
    if (!clientId) return { plans: [] };
    const plans = store.collection('mealPlans')
      .filter((p) => p.clientId === clientId)
      .slice(-20).reverse()
      .map((p) => ({ id: p.id, createdAt: p.createdAt, profile: p.profile, days: p.days }));
    return { plans };
  },

  communityList() {
    // First visit: store the starter recipes for real so they can be upvoted too.
    if (!store.collection('communityRecipes').length) {
      SEED_POSTS().forEach((p) => store.insert('communityRecipes', p, 300));
    }
    const posts = [...store.collection('communityRecipes')];
    posts.sort((a, b) => b.upvotes - a.upvotes || b.createdAt.localeCompare(a.createdAt));
    return { posts: posts.slice(0, 50) };
  },

  communityAdd(body = {}) {
    const title = clean(body.title, 80);
    const author = clean(body.author, 30) || 'A hungry student';
    const steps = clean(body.steps, 600);
    if (title.length < 3) throw new ApiError(400, 'Give your recipe a title.');
    if (steps.length < 10) throw new ApiError(400, 'Add a few words on how to make it.');
    if (!Array.isArray(body.items) || !body.items.length || body.items.length > 12) {
      throw new ApiError(400, 'Pick between 1 and 12 ingredients.');
    }
    const items = body.items.map((i) => {
      const ing = engine.INGREDIENTS[i && i.id];
      const qty = Number(i && i.qty);
      if (!ing) throw new ApiError(400, 'Unknown ingredient.');
      if (!Number.isFinite(qty) || qty <= 0 || qty > 1000) throw new ApiError(400, 'Quantities must be between 0 and 1000.');
      return { id: ing.id, qty };
    });
    // The cost is computed from the shared price table, not typed in, so it can't be faked.
    const priced = engine.priceRecipe(items);
    const post = {
      id: newId(), title, author, steps, items, ...priced,
      upvotes: 0, createdAt: new Date().toISOString(),
    };
    store.insert('communityRecipes', post, 300);
    return { post };
  },

  communityUpvote(id) {
    const doc = store.update('communityRecipes', clean(id, 20), (d) => { d.upvotes += 1; });
    if (!doc) throw new ApiError(404, 'Recipe not found.');
    return { id: doc.id, upvotes: doc.upvotes };
  },
};

function SEED_POSTS() {
  const mk = (id, title, items, steps, upvotes) => ({
    id, title, author: 'PlatePilot team', steps, items, upvotes,
    createdAt: '2026-01-01T00:00:00.000Z', ...engine.priceRecipe(items),
  });
  return [
    mk('seed-1', 'Kettle Masala Oats',
      [{ id: 'oats', qty: 50 }, { id: 'spice', qty: 3 }, { id: 'onion', qty: 20 }, { id: 'peanut', qty: 15 }],
      'Pour boiling water from the kettle over oats, add chopped onion, crushed peanuts and masala. Cover 4 minutes.', 12),
    mk('seed-2', 'Two-Minute Sattu Shake',
      [{ id: 'sattu', qty: 50 }, { id: 'sugar', qty: 10 }, { id: 'lemon', qty: 1 }],
      'Shake sattu, sugar and lemon with cold water in a bottle. Stays full for hours.', 9),
    mk('seed-3', 'Rice Cooker Egg Rice',
      [{ id: 'rice', qty: 90 }, { id: 'egg', qty: 2 }, { id: 'mixveg', qty: 60 }, { id: 'spice', qty: 3 }],
      'Rice, chopped veg and water in the cooker. When almost done, crack the eggs on top, close the lid 5 more minutes, stir.', 7),
  ];
}

const api = {};
for (const [name, fn] of Object.entries(handlers)) api[name] = guard(fn);

module.exports = { api, ApiError };
